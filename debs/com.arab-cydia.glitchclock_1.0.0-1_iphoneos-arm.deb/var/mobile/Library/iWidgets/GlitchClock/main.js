/* Copyright © 0neguy Inc. 2019 */

var $ = document;

var time = document.getElementById("clock")
var date = document.getElementById("date")

var dayText;
var monthText;
var finalMin;
var finalHour;

function prefs() {
    time.style.color = clockColor;
    date.style.color = dateColor;
    if (dateShow === 0) {
        date.style.display = "none";
    }
    if (clockShow === 0) {
        time.style.display = "none";
    }
}

function updateTime() {
    let d = new Date();
    let dayStr = d.getDay();
    let monthStr = d.getMonth();

    if (dayStr === 1) {
        dayText = "mon "
    } else if (dayStr === 2) {
        dayText = "tue ";
    } else if (dayStr === 3) {
        dayText = "wed ";
    } else if (dayStr === 4) {
        dayText = "thu ";
    } else if (dayStr === 5) {
        dayText = "fri ";
    } else if (dayStr === 6) {
        dayText = "sat ";
    } else if (dayStr === 0) {
        dayText = "sun ";
    };


    if (monthStr === 0) {
        monthText = "january";
    } else if (monthStr === 1) {
        monthText = "february";
    } else if (monthStr === 2) {
        monthText = "march";
    } else if (monthStr === 3) {
        monthText = "april";
    } else if (monthStr === 4) {
        monthText = "may";
    } else if (monthStr === 5) {
        monthText = "june";
    } else if (monthStr === 6) {
        monthText = "july";
    } else if (monthStr === 7) {
        monthText = "august";
    } else if (monthStr === 8) {
        monthText = "september";
    } else if (monthStr === 9) {
        monthText = "october";
    } else if (monthStr === 10) {
        monthText = "novemer";
    } else if (monthStr === 11) {
        monthText = "december";
    };

    if (d.getMinutes() < 10) {
        finalMin = "0" + d.getMinutes()
    } else {
        finalMin = d.getMinutes()
    }

    let finalHour = d.getHours();

    if (twelvehr === 1) {
        if (d.getHours() > 12) {
            finalHour -= 12;
        } else if (d.getHours() === 0) {
            finalHour = 12;
        }
    }

    setTimeout(function () {
        if (addZeros === 1) {
            if (finalHour < 10) {
                finalHour = "0" + finalHour;
            }
        }
        time.innerHTML = finalHour + "" + finalMin;
        date.innerHTML = dayText + "// " + d.getDate() + " // " + monthText;
    }, 800)
}

setInterval(function () {
    updateTime();
}, 1000)

document.body.onload = function () {
    updateTime();
    prefs();
    $.body.style.opacity = "1.0";
    $.body.style.transform = "scale(" + widgetSize + ")";
}