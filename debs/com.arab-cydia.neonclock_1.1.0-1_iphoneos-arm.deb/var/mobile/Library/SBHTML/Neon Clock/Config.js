var Language = "0"; // 0 = РУССКИЙ, 1 = ENGLISH
var Format12h = "0"; // 0 = 24h, 1 = 12h
