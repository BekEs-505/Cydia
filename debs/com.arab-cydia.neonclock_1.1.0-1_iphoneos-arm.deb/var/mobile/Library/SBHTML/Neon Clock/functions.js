(function () {
    'use strict';
	
	
    setInterval (function getDate() {
        var date = new Date();
        var weekday = date.getDay();
        var day = date.getDate();
        var hour = date.getHours();
        var minutes = date.getMinutes();

		if (Format12h == 0)
	{
		
        if (hour < 10) hour = "0" + hour;
        if (minutes < 10) minutes = "0" + minutes;
	}
		if (Format12h == 1)
	{
		
        if (hour > 12) hour =  hour - "12";	
		if (hour == 0) hour =  "12";	
        if (minutes < 10) minutes = "0" + minutes;
	}
	
	
		if (Language == 0) var weekdayNames = ["Вс", "Пн", "Вт", "Ср", "Чт", "Пт", "Сб"];
		if (Language == 1) var weekdayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
        

      

        var showDate = day + "__" + weekdayNames[weekday];

        var showTime = hour + ":" + minutes;

        document.querySelector(".time").innerHTML = showTime;

        document.querySelector(".date").innerHTML = showDate;
		
    }, 1000);
	

   

}());


