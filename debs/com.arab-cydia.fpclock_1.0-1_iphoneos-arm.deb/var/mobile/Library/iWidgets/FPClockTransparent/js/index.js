const gradient = document.querySelector('.bg');
const analog = document.querySelector('.analog > span');
const hour = document.querySelector('.hour');
const second = document.querySelector('.second');

let time;

const updateTime = () => {
  time = new Date().toTimeString();
}
const updateAnalog = () => { 
  analog.textContent = time.substr(0, 5);
};
const updateMinuteGradient = () => {
  let mins = time.substring(3, 5);
  let rotation = mins * 6;
  second.style.transform = `translate(-50%, -50%) rotate(${rotation}deg)`;
}
const updateHour = () => {
  let hr = time.substring(0,2);
  let rotation = hr * 30;
  hour.style.transform = `translate(-50%, -50%) rotate(${rotation}deg)`;
}
const updateSecond = () => {
  let sec = time.substring(6, 8);
  let rotation = sec * 6;
  gradient.style.transform = `translate(-50%, -50%) rotate(${rotation}deg)`;
}

const updateClock = () => {
  updateTime();
  updateAnalog();
  updateMinuteGradient();
  updateHour();
  updateSecond();
}
setInterval(updateClock, 1000);

// change gradient color based on time of day