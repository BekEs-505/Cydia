var Color1 = "red"; // use hexcode to be exact
var Color2 = "blue"; // use hexcode to be exact
var Color3 = "green"; // use hexcode to be exact
var Color4 = "yellow"; // use hexcode to be exact
var Color5 = "pink"; // use hexcode to be exact
