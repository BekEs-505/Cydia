var createDOM = function(params) {
    var d = document.createElement(params.type);
    if (params.className) {
        d.setAttribute('class', params.className);
    }
    if (params.id) {
        d.id = params.id;
    }
    if (params.innerHTML) {
        d.innerHTML = params.innerHTML;
    }
    if (params.attribute) {
        d.setAttribute(params.attribute[0], params.attribute[1]);
    }
    return d;
};