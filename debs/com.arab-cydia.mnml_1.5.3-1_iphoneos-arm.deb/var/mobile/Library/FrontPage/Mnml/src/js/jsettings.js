/*


Requires lStorage, jPopup, and spectrum

    Usage:
        jSettings({
            options: ['colorMenu', 'panelColor'],
            colorMenu: {
                saveName: '',
                type: 'menu',
                menuID: 'colorMenu',
                placeholder: 'Color Options',
                callback: function(menu){
                    jSettings.closeSettings();
                    setTimeout(function(){
                        menu.style.display = 'block';
                    },300);
                }
            },
            panelColor: {
                menu: 'colorMenu',
                saveName: 'panelColor',
                type: 'input',
                color: true,
                defaultColor: 'rgba(0, 0, 0, 0.6)',
                placeholder: 'Dock Color',
                callback: function(input, ref){
                    document.querySelector('.panel').style.backgroundColor = input.value;
                    if(ref){
                        lStorage.replaceStorageItem(ref, input.value);
                    }
                }
            }
        });

    Hide/Show panel
        Main Panel jSettings.closeSettings()
        All other panels jSettings.closeSettingsMenus();
*/

(function() {
    var doc = document,
        jSettings = function (j) {
            var createDOM = function (params) {
                var d = document.createElement(params.type);
                if (params.className) {
                    d.setAttribute('class', params.className);
                }
                if (params.id) {
                    d.id = params.id;
                }
                if (params.innerHTML) {
                    d.innerHTML = params.innerHTML;
                }
                if (params.attribute) {
                    d.setAttribute(params.attribute[0], params.attribute[1]);
                }
                return d;
            },
            storedItems = null,
            registerPopupEvents = function (div, params) {
                div.addEventListener(params.event, params.callback);
            },
            addEventToButton = function(button, type, action, param1, param2){
                registerPopupEvents(button, {
                    event: type,
                    callback: function (el) {
                        if(param1){
                            action(param1, param2);
                        }else{
                            action();
                        }
                    }
                });
            },
            callEvent = function(action, param1, param2){
                if(param1){
                    action(param1, param2);
                }else{
                    action();
                }
            };
            createInput = function(j, div, itemObject){
                var text = createDOM({
                    type: 'div',
                    className: 'itemLabel',
                    id: j.options[i],
                    innerHTML: itemObject.placeholder
                });
                var input = createDOM({
                    type: 'input',
                    className: 'itemInput'
                });
                
                if(itemObject.color){
                    setTimeout(function(){
                        //load saved color
                        if(!storedItems){
                            storedItems = JSON.parse(localStorage.getItem(lStorage.storageName));
                        }
                        //if no stored color use default color
                        var color = itemObject.defaultColor;
                        if(storedItems && storedItems[itemObject.saveName]){
                            color = storedItems[itemObject.saveName];
                        }
                        //add input for color picker
                        $(input).spectrum({
                            preferredFormat: "rgb",
                            showAlpha: true,
                            showInput: true,
                            color: color,
                            move: function(color) {
                                this.value = color.toRgbString();
                                callEvent(itemObject.callback, input, itemObject.saveName);
                            },
                            change: function(color) {
                                callEvent(itemObject.callback, input, itemObject.saveName);
                            }
                        });
                        var inputs = document.getElementsByClassName('sp-input');
                            for (var i = 0; i < inputs.length; i++) {
                                if(inputs[i] !== undefined){
                                    inputs[i].addEventListener('focus', function(el){
                                        var offsetFromCenter = el.target.getBoundingClientRect().top - ((screen.height/2) - 40);
                                        $('html, body').animate({
                                            top: -offsetFromCenter
                                        }, 'fast');
                                    });
                                    inputs[i].addEventListener('blur', function(){
                                        $('html, body').animate({
                                            top: 0
                                        }, 'fast');
                                    });
                                }
                            }
                    },200);
                }else{
                    input.addEventListener('focus',function(el){
                        var offsetFromCenter = el.target.getBoundingClientRect().top - ((screen.height/2) - 40);
                        $('html, body').animate({
                            top: -offsetFromCenter
                        }, 'fast');
                    });
                    input.addEventListener('blur',function(){
                        $('html, body').animate({
                            top: 0
                        }, 'fast');
                    });
                }

                if(itemObject.example){
                    input.placeholder = itemObject.example;
                }

                //if item has menu defined place it in that menu.
                if(itemObject.menu){
                    var menu = document.getElementById(itemObject.menu);
                    if(menu.children[0].className === 'jElements'){
                        menu = menu.children[0];
                    }

                    menu.appendChild(text);
                    menu.appendChild(input);
                }else{
                    div.appendChild(text);
                    div.appendChild(input);
                }
                if(lStorage[itemObject.saveName]){
                    input.value = lStorage[itemObject.saveName];
                    itemObject.callback(input);
                }
                addEventToButton(input, 'blur', itemObject.callback, input, itemObject.saveName);
            },
            createToggle = function(j, div, itemObject){
                var text = createDOM({
                    type: 'div',
                    className: 'itemLabel',
                    id: j.options[i],
                    innerHTML: itemObject.placeholder
                }),
                holder = createDOM({
                    type: 'div',
                    className: 'toggleHolder'
                }),
                label = createDOM({
                    type: 'label',
                    className: 'switch'
                }),
                input = createDOM({
                    type: 'input',
                    attribute: ['type', 'checkbox']
                }),
                span = createDOM({
                    type: 'span',
                    className: 'slider round'
                });
                //if item has menu defined place it in that menu.
                if(itemObject.menu){
                    var menu = document.getElementById(itemObject.menu);
                    if(menu.children[0].className === 'jElements'){
                        menu = menu.children[0];
                    }

                    menu.appendChild(text);
                    holder.appendChild(label);
                    holder.appendChild(input);
                    holder.appendChild(span);
                    menu.appendChild(holder);
                }else{
                    div.appendChild(text);
                    holder.appendChild(label);
                    holder.appendChild(input);
                    holder.appendChild(span);
                    div.appendChild(holder);
                }
                
                if(lStorage[itemObject.saveName]){
                    input.checked = true;
                    itemObject.callback(input);
                }
                addEventToButton(input, 'change', itemObject.callback, input, itemObject.saveName);
            },
            createButton = function(j, div, itemObject){
                var text = createDOM({
                    type: 'div',
                    className: 'itemLabel',
                    id: j.options[i],
                    //innerHTML: itemObject.placeholder
                }),
                button = createDOM({
                    type: 'div',
                    className: 'jButton',
                    innerHTML: itemObject.placeholder
                });
                //if item has menu defined place it in that menu.
                if(itemObject.menu){
                    var menu = document.getElementById(itemObject.menu);
                    if(menu.children[0].className === 'jElements'){
                        menu = menu.children[0];
                    }
                    menu.appendChild(text);
                    menu.appendChild(button);
                }else{
                    div.appendChild(text);
                    div.appendChild(button);
                }
                addEventToButton(button, 'touchstart', itemObject.callback);
            },
            createMenu = function(j, div, itemObject){
                var menuButton = createDOM({
                    type: 'div',
                    className: 'jMenuButton',
                    innerHTML: itemObject.placeholder
                }),
                menu = createDOM({
                    type:'div',
                    className: 'jSettingsMenu',
                    id: itemObject.menuID
                }),
                systemElements = createDOM({
                    type: 'div',
                    className: 'jElements'
                });
                menu.appendChild(systemElements);
                document.body.appendChild(menu);
                div.appendChild(menuButton);
                addEventToButton(menuButton, 'touchend', itemObject.callback, menu);
            },
            systemPopup = createDOM({
                type: 'div',
                id: 'jSettings'
            }),
            systemElements = createDOM({
                type: 'div',
                className: 'jElements'
            });
            for (var i = 0; i < j.options.length; i++) {
                var itemObject = j[j.options[i]],
                    div = createDOM({
                        type: 'div',
                        className: itemObject.saveName + '~' + itemObject.type
                    });
                if(itemObject.type === 'input'){
                    createInput(j, div, itemObject);
                }
                if(itemObject.type === 'toggle'){
                    createToggle(j, div, itemObject);
                }
                if(itemObject.type === 'button'){
                    createButton(j, div, itemObject);
                }
                if(itemObject.type === 'menu'){
                    createMenu(j, div, itemObject);
                }
                systemElements.appendChild(div);
            }
            systemPopup.appendChild(systemElements);
            doc.body.appendChild(systemPopup);
            jSettings.savedElements = j.options;
        }
        jSettings.closeSettings = function(){
            document.getElementById('jSettings').style.display = "none";
        };
        jSettings.closeSettingsMenus = function(){
            var divs = document.getElementsByClassName('jSettingsMenu');
            for (var i = 0; i < divs.length; i++) {
                divs[i].style.display = 'none';
            }
        };
        jSettings.closeColorPickers = function(){
            if(document.getElementsByClassName('sp-container')){
                var containers = document.getElementsByClassName('sp-container');
                if(containers.length > 0){
                    for (var i = 0; i < containers.length; i++) {
                        if(!containers[i].classList.contains('sp-hidden')){
                            containers[i].className += ' sp-hidden';
                        }
                    }
                }
            }
        };
    window.jSettings = jSettings;
}());


