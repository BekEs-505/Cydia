



var sblayouts = {
	layoutObjects: [],
	saveLayout: function () {
		var layoutName = document.getElementById('myLayoutName').value,
			i,
			myNewLayout;
		if(layoutName){
			myNewLayout = {
				name: layoutName
			};
			for (i = 0; i < storageNames.length; i++) { 
				if(localStorage.getItem(storageNames[i]) !== null){
					myNewLayout[storageNames[i]] = localStorage.getItem(storageNames[i]);
				}
			}
			sblayouts.layoutObjects.push(myNewLayout);
			localStorage.sbmylayouts = JSON.stringify(sblayouts.layoutObjects);
			jPopup({
                type: "alert",
                message: "Layout saved, to remove tap and hold layout below.",
                okButtonText: "OK"
            });
		}else{
			jPopup({
                type: "alert",
                message: "You must enter a layout name.",
                okButtonText: "OK"
            });
		}
		sblayouts.initLayouts();
		document.getElementById('myLayoutName').value = "";
	},
	initLayouts: function () {
		var layoutHolder = document.getElementById('savedLayouts'),
			i,
			d;
		layoutHolder.innerHTML = "";
		sblayouts.layoutObjects = JSON.parse(localStorage.sbmylayouts);
		for (i = 0; i < sblayouts.layoutObjects.length; i++) {
			d = document.createElement('div');
			d.innerHTML = sblayouts.layoutObjects[i].name;
			d.className = "button";
			layoutHolder.appendChild(d);
		}
	},
	deleteLayout: function () {
		var layoutName = document.getElementById('deletemyLayoutName').value,
			i;
		if(layoutName){
			for (i = 0; i < sblayouts.layoutObjects.length; i++) {
				if(sblayouts.layoutObjects[i].name == layoutName){
					sblayouts.layoutObjects.splice(i, 1);
					localStorage.sbmylayouts = JSON.stringify(sblayouts.layoutObjects);
					sb.reload();
					sblayouts.initLayouts();
				}
			}
		}else{
			jPopup({
                type: "alert",
                message: "You must enter a layout name to delete it.",
                okButtonText: "OK"
            });
		}
	},
	removeLayout: function (layoutName){
		for (i = 0; i < sblayouts.layoutObjects.length; i++) {
			if(sblayouts.layoutObjects[i].name == layoutName){
				sblayouts.layoutObjects.splice(i, 1);
				localStorage.sbmylayouts = JSON.stringify(sblayouts.layoutObjects);
				sb.reload();
				sblayouts.initLayouts();
			}
		}
	},
	loadLayout: function(layout) {
		widgets.clearWidgets();
		setTimeout(function(){
			var i, e, f, stArray = [];
			for (i = 0; i < sblayouts.layoutObjects.length; i++) {
				if(sblayouts.layoutObjects[i].name == layout){
					for (e = 0; e < storageNames.length; e++) { 
						if(sblayouts.layoutObjects[i][storageNames[e]] != undefined){
							if(sblayouts.layoutObjects[i][storageNames[e]] !== null){
								stArray.push(storageNames[e]);
								console.log(storageNames[e]);
								console.log(sblayouts.layoutObjects[i][storageNames[e]]);
								localStorage.setItem(storageNames[e], sblayouts.layoutObjects[i][storageNames[e]]);
							}
						}
					}
				}
			}
			for (f = 0; f < storageNames.length; f++) {
				if (!stArray.contains(storageNames[f])) {
					localStorage.removeItem(storageNames[f]);
				}
			}
			
			sb.reload();
			sblayouts.initLayouts();
			doc.getElementById('layoutOptionsMenu').style.display = "none";
		}, 0);
	}
};

if(localStorage.sbmylayouts){
	sblayouts.initLayouts();
}
