var colorPicker = {
	init: function(){
		$('#folderColorInput').spectrum({
		    preferredFormat: "rgb",
		    showAlpha: true,
		    showInput: true,
		    color: localStorage.foldercolor || 'rgba(0,0,0,0.6)',
		    move: function(color) {

		    },
		    change: function(color) {
		        folders.setBGColor(color);
		    }
		});

		$('#badgeColorInput').spectrum({
		    preferredFormat: "rgb",
		    showAlpha: true,
		    showInput: true,
		    color: localStorage.sbbadgecolor || 'rgba(0,0,0,0.8)',
		    move: function(color) {

		    },
		    change: function(color) {
		    	localStorage.sbbadgecolor = color;
		        sbMenu.setBadgeColor(color);
		    }
		});

		$('#badgeBorderColorInput').spectrum({
		    preferredFormat: "rgb",
		    showAlpha: true,
		    showInput: true,
		    color: localStorage.sbbadgebordercolor || 'rgba(255,255,255,0.7)',
		    move: function(color) {

		    },
		    change: function(color) {
		    	sbMenu.setBadgeBorderColor(color);
    			localStorage.sbbadgebordercolor = color;
		    }
		});

		$('#badgeTextColorInput').spectrum({
		    preferredFormat: "rgb",
		    showAlpha: true,
		    showInput: true,
		    color: localStorage.sbbadgetextcolor || 'white',
		    move: function(color) {

		    },
		    change: function(color) {
		    	sbMenu.setBadgeTextColor(color);
    			localStorage.sbbadgetextcolor = color;
		    }
		});

		$('#drawerBackgroundColorInput').spectrum({
		    preferredFormat: "rgb",
		    showAlpha: true,
		    showInput: true,
		    color: localStorage.drawerBGColor || 'rgba(0,0,0,0.3)',
		    move: function(color) {

		    },
		    change: function(color) {
		        drawerOptions.changeOption('backgroundcolor', color);
		    }
		});

		$('#drawerBadgeBGColorInput').spectrum({
		    preferredFormat: "rgb",
		    showAlpha: true,
		    showInput: true,
		    color: localStorage.drawerBadgeColor || 'black',
		    move: function(color) {

		    },
		    change: function(color) {
		        drawerOptions.changeOption('badgecolor', color);
		    }
		});

		$('#drawerBadgeTextColorInput').spectrum({
		    preferredFormat: "rgb",
		    showAlpha: true,
		    showInput: true,
		    color: localStorage.drawerTextColor || 'white',
		    move: function(color) {

		    },
		    change: function(color) {
		        drawerOptions.changeOption('badgetextcolor', color);
		    }
		});


		$('#drawerLabelColorInput').spectrum({
		    preferredFormat: "rgb",
		    showAlpha: true,
		    showInput: true,
		    color: localStorage.drawerLabelColor || 'white',
		    move: function(color) {

		    },
		    change: function(color) {
		        drawerOptions.changeOption('labelcolor', color);
		    }
		});

		$('#drawerShortcutTextColorInput').spectrum({
		    preferredFormat: "rgb",
		    showAlpha: true,
		    showInput: true,
		    color: localStorage.drawershortcutTextColor || 'black',
		    move: function(color) {

		    },
		    change: function(color) {
		        drawerOptions.changeOption('shortcuttext', color);
		    }
		});

		$('#drawerShortcutBGColorInput').spectrum({
		    preferredFormat: "rgb",
		    showAlpha: true,
		    showInput: true,
		    color: localStorage.drawershortcutBGColor || 'rgba(0, 0, 0, 0.1)',
		    move: function(color) {

		    },
		    change: function(color) {
		        drawerOptions.changeOption('shortcutbg', color);
		    }
		});

		$('#pageDotColorDisabledInput').spectrum({
		    preferredFormat: "rgb",
		    showAlpha: true,
		    showInput: true,
		    color: localStorage.pageDotDisabledColor || 'rgba(255,255,255,0.6)',
		    move: function(color) {

		    },
		    change: function(color) {
		        PageDots.changeColor('disabled', color);
		    }
		});

		$('#pageDotColorHighlightInput').spectrum({
		    preferredFormat: "rgb",
		    showAlpha: true,
		    showInput: true,
		    color: localStorage.pageDotHighlightColor || 'rgba(255,255,255,0.9)',
		    move: function(color) {

		    },
		    change: function(color) {
		        PageDots.changeColor('highlight', color);
		    }
		});

		$('#labelColorInput').spectrum({
		    preferredFormat: "rgb",
		    showAlpha: true,
		    showInput: true,
		    color: localStorage.sblabelcolor || 'white',
		    move: function(color) {

		    },
		    change: function(color) {
		        sbMenu.setLabelColor(color);
    			localStorage.sblabelcolor = color;
		    }
		});

		$('#wifiColorInput').spectrum({
		    preferredFormat: "rgb",
		    showAlpha: true,
		    showInput: true,
		    color: localStorage.sbwificolor || 'white',
		    move: function(color) {

		    },
		    change: function(color) {
		        Statusbar.setWifiColor(color);
		    }
		});
		$('#signalColorInput').spectrum({
		    preferredFormat: "rgb",
		    showAlpha: true,
		    showInput: true,
		    color: localStorage.sbsignalcolor || 'white',
		    move: function(color) {

		    },
		    change: function(color) {
		        Statusbar.setSignalColor(color);
		    }
		});
		$('#batteryColorInput').spectrum({
		    preferredFormat: "rgb",
		    showAlpha: true,
		    showInput: true,
		    color: localStorage.sbbatterycolor || 'white',
		    move: function(color) {

		    },
		    change: function(color) {
		        Statusbar.setBatteryColor(color);
		    }
		});
		
	}
};