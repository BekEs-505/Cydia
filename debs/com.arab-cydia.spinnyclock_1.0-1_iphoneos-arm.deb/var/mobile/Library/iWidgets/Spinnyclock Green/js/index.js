
var s = document.getElementById('seconds');
var m = document.getElementById('minutes');
var h = document.getElementById('hours');
var d = document.getElementById('digital');

setInterval(function(){
  var date = new Date;
  var seconds = date.getSeconds();
  var minutes = date.getMinutes();
  var hour = date.getHours();
  var ampm = hour > 11 ? 'pm' : 'am';
  hour = hour % 12;
  hour = hour ? hour : 12;
  // console.log(hour);
  setDashArray(s, seconds, 60);
  setDashArray(m, minutes, 60);
  setDashArray(h, hour, 12);
  d.innerHTML = hour + ':' + minutes;
}, 1000);

function setDashArray(el, value, o) {
  var r = el.getAttribute('r');
  var cir = (2 * Math.PI * r);
  var percent = value / o;
  var inc = cir *  percent;
 el.setAttribute('stroke-dasharray', inc + ', ' + cir)
}