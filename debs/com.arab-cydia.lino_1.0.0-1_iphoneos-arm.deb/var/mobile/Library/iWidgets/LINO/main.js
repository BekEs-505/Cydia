/* Copyright © 0neguy Inc. 2019 */

var $ = document;

var clockDiv = document.getElementById("clock")
var hoursDiv = document.getElementById("hours")
var minutesDiv = document.getElementById("minutes")

var finalMin;
var finalHour;

function prefs() {
    minutesDiv.style.color = minuteColor;
    hoursDiv.style.color = hourColor;

    widget.style.opacity = widgetOpacity;
}

/* 
var twelvehr = 1;
var minuteColor = "#FF6A33";
var hourColor = "#000000";
var widgetSize = "1.0"
var widgetOpacity = "1.0"
var clockShow = 1;
*/

function updateTime() {
    let d = new Date();

    if (d.getMinutes() < 10) {
        finalMin = "0" + d.getMinutes()
    } else {
        finalMin = d.getMinutes()
    }

    let finalHour = d.getHours();

    if (twelvehr === 1) {
        if (d.getHours() > 12) {
            finalHour -= 12;
        } else if (d.getHours() === 0) {
            finalHour = 12;
        }
    }

    setTimeout(() => {
        if (finalHour < 10) {
            finalHour = "0" + finalHour;
        }

        hoursDiv.innerHTML = finalHour;
        minutesDiv.innerHTML = finalMin;
    }, 800)
}

setInterval(() => {
    updateTime();
}, 1000)

document.body.onload = () => {
    updateTime();
    prefs();
    $.body.style.opacity = "1.0";
    $.body.style.transform = "scale(" + widgetSize + ")";
}