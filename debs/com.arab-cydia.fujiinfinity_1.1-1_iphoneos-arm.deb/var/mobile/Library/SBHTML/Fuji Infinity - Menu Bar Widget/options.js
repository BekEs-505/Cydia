var iphoneXmode = false; //Toggle iPhone X/XS mode
var darkmode = true; //Toggle darkmode
var batteryview = true; //Toggle battery view (requires InfoStats - compatible with iOS 12)
var twelvehour = false; // Toggle 12/24-hour clock
var backgroundBlur = false; //Toggle homescreen background blur
var blurradius = 15; //Background blur radius (in pixels)