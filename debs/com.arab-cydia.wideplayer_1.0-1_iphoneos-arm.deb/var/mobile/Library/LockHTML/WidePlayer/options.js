var Hidden = false; //Hide WidePlayer when not playing
var DarkeningView = true; //Add a black color overlay to enhance readablity (recommended)
var HideTitle = false; //Hide song title and artist text