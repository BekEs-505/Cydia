var appSettings = {
    addEvents: function(){
        tripleTap({
            div: document.getElementById('pageHolder'),
            callback: function(){
                document.getElementById('jSettings').style.display = "block";
            }
        });
        document.getElementById('pageHolder').addEventListener('touchstart', function(el){
            if(el.target.className === 'page'){
                jSettings.closeSettings();
                jSettings.closeSettingsMenus();
                jSettings.closeColorPickers();
            }
        });
    },
    addSettings: function(){
        jSettings({
            options: ['colorMenu', 'toggleMenu', 'hidePageButtons', 'drawerButtonColor', 'badgeBGColor', 'badgeTextColor', 'panelTextColors', 'panelColors', 'imagePanelOpacity', 'drawerBGColor', 'drawerBadgeColor', 'drawerLabelColor', 'drawerShortcutColor', 'roundDrawer', 'drawerShadow', 'iconRoundness', 'info', 'clearUserSettings', 'respring'],
            colorMenu: {
                saveName: '',
                type: 'menu',
                menuID: 'colorMenu',
                placeholder: 'Color Options',
                callback: function(menu){
                    jSettings.closeSettings();
                    menu.style.display = 'block';
                }
            },
            toggleMenu:{
                saveName: '',
                type: 'menu',
                menuID: 'toggleMenu',
                placeholder: 'Toggles',
                callback: function(menu){
                    jSettings.closeSettings();
                    menu.style.display = 'block';
                }
            },
            drawerBGColor: {
                menu: 'colorMenu',
                saveName: 'drawerBGColor',
                type: 'input',
                color: true,
                defaultColor: 'rgba(0,0,0,0.3)',
                placeholder: 'Drawer bg Color',
                callback: function(input, ref){
                    changeCSS.addRule(document.styleSheets[0], ".drawer_main", "background-color: " + input.value + "!important;");
                    if(ref){
                        lStorage.replaceStorageItem(ref, input.value);
                    }
                }
            },
            drawerBadgeColor: {
                menu: 'colorMenu',
                saveName: 'drawerBadgeColor',
                type: 'input',
                color: true,
                defaultColor: 'black',
                placeholder: 'Drawer badge Color',
                callback: function(input, ref){
                    changeCSS.addRule(document.styleSheets[0], ".drawer_icon::before", "background-color: " + input.value + "!important;");
                    if(ref){
                        lStorage.replaceStorageItem(ref, input.value);
                    }
                }
            },
            drawerLabelColor: {
                menu: 'colorMenu',
                saveName: 'drawerLabelColor',
                type: 'input',
                color: true,
                defaultColor: 'white',
                placeholder: 'Drawer label Color',
                callback: function(input, ref){
                    changeCSS.addRule(document.styleSheets[0], ".drawer_icon::after", "color: " + input.value + "!important;");
                    if(ref){
                        lStorage.replaceStorageItem(ref, input.value);
                    }
                }
            },
            drawerShortcutColor: {
                menu: 'colorMenu',
                saveName: 'drawerShortcutColor',
                type: 'input',
                color: true,
                defaultColor: 'white',
                placeholder: 'Drawer shortcut Color',
                callback: function(input, ref){
                    changeCSS.addRule(document.styleSheets[0], ".shortcut", "color: " + input.value + "!important;");
                    if(ref){
                        lStorage.replaceStorageItem(ref, input.value);
                    }
                }
            },
            roundDrawer: {
                menu: 'toggleMenu',
                saveName: 'roundDrawer',
                type: 'toggle',
                placeholder: 'Round drawer icons',
                callback: function(input, ref){
                    if(input.checked){
                        changeCSS.addRule(document.styleSheets[0], ".drawer_icon", "border-radius: 99px!important;");
                    }else{
                        changeCSS.addRule(document.styleSheets[0], ".drawer_icon", "border-radius: 0px!important;");
                    }
                    if(ref){
                        lStorage.replaceStorageItem(ref, input.checked);
                    }
                }
            },
            drawerShadow: {
                menu: 'toggleMenu',
                saveName: 'drawerShadow',
                type: 'toggle',
                placeholder: 'Drawer shadows',
                callback: function(input, ref){
                    if(input.checked){
                        changeCSS.addRule(document.styleSheets[0], ".drawer_icon", "box-shadow: 0 8px 6px -6px rgba(0,0,0,0.6)!important;");
                    }else{
                        changeCSS.addRule(document.styleSheets[0], ".drawer_icon", "box-shadow: 0 8px 6px -6px rgba(0,0,0,0)!important;");
                    }
                    if(ref){
                        lStorage.replaceStorageItem(ref, input.checked);
                    }
                }
            },
            hidePageButtons: {
                menu: 'toggleMenu',
                saveName: 'hidePageButtons',
                type: 'toggle',
                placeholder: 'Hide page buttons',
                callback: function(input, ref){
                    if(input.checked){
                        changeCSS.addRule(document.styleSheets[0], ".goLeft", "display:none;");
                        changeCSS.addRule(document.styleSheets[0], ".goRight", "display:none;");
                    }else{
                        changeCSS.addRule(document.styleSheets[0], ".goLeft", "display:block;");
                        changeCSS.addRule(document.styleSheets[0], ".goRight", "display:block;");
                    }
                    if(ref){
                        lStorage.replaceStorageItem(ref, input.checked);
                    }
                }
            },
            drawerButtonColor: {
                menu: 'colorMenu',
                saveName: 'drawerButtonColor',
                type: 'input',
                color: true,
                defaultColor: 'rgba(255, 255, 255, 1)',
                placeholder: 'Drawer button color',
                callback: function(input, ref){
                    changeCSS.addRule(document.styleSheets[0], "#openDrawer::after", "background-color: " + input.value + "!important;");
                    if(ref){
                        lStorage.replaceStorageItem(ref, input.value);
                    }
                }
            },
            badgeBGColor: {
                menu: 'colorMenu',
                saveName: 'badgeBGColor',
                type: 'input',
                color: true,
                defaultColor: 'rgba(0, 0, 0, 1)',
                placeholder: 'Badge BG Color',
                callback: function(input, ref){
                    changeCSS.addRule(document.styleSheets[0], ".badge", "background-color: " + input.value + "!important;");
                    if(ref){
                        lStorage.replaceStorageItem(ref, input.value);
                    }
                }
            },
            badgeTextColor: {
                menu: 'colorMenu',
                saveName: 'badgeTextColor',
                type: 'input',
                color: true,
                defaultColor: 'rgba(255, 255, 255, 1)',
                placeholder: 'Badge Text Color',
                callback: function(input, ref){
                    changeCSS.addRule(document.styleSheets[0], ".badge::after", "color: " + input.value + "!important;");
                    changeCSS.addRule(document.styleSheets[0], ".badge", "color: " + input.value + "!important;");
                    if(ref){
                        lStorage.replaceStorageItem(ref, input.value);
                    }
                }
            },
            panelColors: {
                menu: 'colorMenu',
                saveName: 'panelColors',
                type: 'input',
                color: true,
                defaultColor: 'rgba(255, 255, 255, 1)',
                placeholder: 'Panel BG Color',
                callback: function(input, ref){
                    changeCSS.addRule(document.styleSheets[0], ".goLeft::after", "background-color: " + input.value + "!important;");
                    changeCSS.addRule(document.styleSheets[0], ".goRight::after", "background-color: " + input.value + "!important;");
                    changeCSS.addRule(document.styleSheets[0], ".panel", "background-color: " + input.value + "!important;");
                    //applied color to the blur image bg container
                    // changeCSS.addRule(document.styleSheets[0], ".firstCenterContainerBlur", "background-color: " + input.value + "!important;");
                    // changeCSS.addRule(document.styleSheets[0], ".secondCenterContainerBlur", "background-color: " + input.value + "!important;");
                    // changeCSS.addRule(document.styleSheets[0], ".thirdCenterContainerBlur", "background-color: " + input.value + "!important;");
                    if(ref){
                        lStorage.replaceStorageItem(ref, input.value);
                    }
                }
            },
            panelTextColors: {
                menu: 'colorMenu',
                saveName: 'panelTextColors',
                type: 'input',
                color: true,
                defaultColor: 'rgba(0, 0, 0, 1)',
                placeholder: 'Panel Text Color',
                callback: function(input, ref){
                    changeCSS.addRule(document.styleSheets[0], ".panel div:not(.badge)", "color: " + input.value + "!important;");
                    changeCSS.addRule(document.styleSheets[0], "#forecast span", "color: " + input.value + "!important;");
                    if(ref){
                        lStorage.replaceStorageItem(ref, input.value);
                    }
                }
            },
            imagePanelOpacity:{
                menu: 'colorMenu',
                saveName: 'imagePanelOpacity',
                type: 'input',
                color: true,
                defaultColor: 'rgba(0, 0, 0, 1)',
                placeholder: 'Image opacity',
                callback: function(input, ref){
                    var alpha = input.value.replace(/^.*,(.+)\)/,'$1');
                    changeCSS.addRule(document.styleSheets[0], ".firstCenterContainer", "opacity: " + alpha + "!important;");
                    changeCSS.addRule(document.styleSheets[0], ".secondCenterContainer", "opacity: " + alpha + "!important;");
                    changeCSS.addRule(document.styleSheets[0], ".thirdCenterContainer", "opacity: " + alpha + "!important;");
                    if(ref){
                        lStorage.replaceStorageItem(ref, input.value);
                    }
                }
            },
            iconRoundness: {
                saveName: 'iconRoundness',
                type: 'input',
                example: 'Number 0-100',
                placeholder: 'Dock icon roundness (8)',
                callback:function(input, ref){
                    changeCSS.addRule(document.styleSheets[0], "#iconHolder div", "border-radius: " + input.value + "px!important;");
                    if(ref){
                        lStorage.replaceStorageItem(ref, input.value);
                    }
                }
            },
            respring: {
                saveName: 'respring',
                type: 'button',
                placeholder: 'Respring device',
                callback: function(input, ref){
                    location.href = 'frontpage:respring';
                }
            },
            info: {
                saveName: 'info',
                type: 'button',
                placeholder: 'Theme Info',
                callback: function(input, ref){
                var message = "Change images by replacing the images in var/mobile/Library/FrontPage/TriSet/css/images/";
                    //message += "<br></br>Each page has a css file that controls it. You can use these .css files to modify panel colors and more.";
                    jPopup({
                        type: "alert",
                        message: message,
                        okButtonText: "OK"
                    });
                }
            },
            clearUserSettings: {
                saveName: 'clearUserSettings',
                type: 'button',
                placeholder: 'Clear all user settings',
                callback: function(input, ref){
                    jSettings.closeSettings();
                    jPopup({
                        type: "confirm",
                        message: "This clears all settings back to default. Are you sure you want to do this?",
                        yesButtonText: "Yes",
                        noButtonText: "No",
                        functionOnNo: function() {
                            
                        },
                        functionOnOk: function() {
                            localStorage.removeItem(lStorage.storageName);
                            location.href = location.href;
                        }
                    });
                }
            },
        });
    },
    initSettings: function(){
        this.addSettings();
        this.addEvents();
    }
};




