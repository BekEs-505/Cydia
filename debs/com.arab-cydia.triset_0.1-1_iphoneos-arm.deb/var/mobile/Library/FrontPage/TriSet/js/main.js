var triPageFP = {
	holder : document.getElementById('iconHolder'),
	controls: document.getElementById('controls'),
	changingIcon: false,
	changingApp: false,
	isMovingPage: false,
	target: null,
	addEvents: function(){
		document.getElementById('openDrawer').addEventListener('touchstart', function(){
            FPI.drawer.toggleDrawer();
        });
        document.querySelector('.searchText').addEventListener('touchstart', function(){
        	window.location = 'frontpage:opensearch';
        });
        this.holder.addEventListener('touchend', function(el){
            var bundle = el.target.getAttribute('bundle');
            if(bundle && !triPageFP.changingIcon && !triPageFP.changingApp){
                openApp(bundle);
            }
        });
        taphold({
            time: 400,
            element: this.holder,
            action: function(target) {
                triPageFP.showPopup(target);
            },
            passTarget: true
        });
        this.controls.addEventListener('touchstart', function(el){
            if(el.target.id === 'play'){
                window.location = 'frontpage:playmusic';
            }
            if(el.target.id === 'next'){
                window.location = 'frontpage:nexttrack';
            }
            if(el.target.id === 'prev'){
                window.location = 'frontpage:prevtrack';
            }
        });
	},
	showPopup: function(target) {
        this.changingIcon = true;
        this.changingApp = true;
        this.target = target;
        jPopup({
            type: "confirm",
            message: "Choose an option below",
            yesButtonText: "Set App",
            noButtonText: "Set Icon",
            functionOnNo: function() {
                this.changeIcon = true;
                window.location = 'frontpage:loadIconBrowser';
            },
            functionOnOk: function() {
                this.changeApp = true;
                FPI.drawer.toggleDrawer({
                    state: 'changingApp',
                    callback: function(newApp) {
                        triPageFP.changingIcon = false;
                        triPageFP.changingApp = false;
                        lStorage.replaceInAppArray('iconHolderBundles', triPageFP.target.getAttribute('bundle'), newApp);
                        triPageFP.loadSavedApps();
                    }
                });
            }
        });
    },
	loadSavedApps: function(){
        this.holder.innerHTML = "";
        var iconBundles = lStorage.iconHolderBundles;
        for (var i = 0; i < iconBundles.length; i++) {
            var div = document.createElement('div'),
                bundle = iconBundles[i],
                badgeTxt = "",
                icon = '/var/mobile/Library/FrontPageCache/' + bundle + '.png';
                if (lStorage.iconImageLocations[bundle]) {
                    icon = lStorage.iconImageLocations[bundle];
                }
                if(FPI.bundle[bundle]){
                        //app is installed
                        if(FPI.bundle[bundle].badge > 0){
                            if(FPI.bundle[bundle].badge > 99){
                            badgeTxt = "...";
                        }else{
                            badgeTxt = FPI.bundle[bundle].badge;
                        }
                        div.innerHTML = "<div title='" + badgeTxt + "' class='badge'></div>";
                    }else{
                        div.innerHTML = "";
                    }
                }else{
                    //app isn't installed or doesn't exist, give default icon.
                    icon = "css/addApp.png";
                }
                div.id = bundle;
                div.className = 'icon';
                div.setAttribute('bundle', bundle);
                div.style.backgroundImage = 'url("' + icon + '")';
                this.holder.appendChild(div);
        }
    },
	initStorage: function(){
        lStorage.init({
            name: 'triPageFP',
            storedNames: ['iconImageLocations', 'iconHolderBundles','hidePageButtons', 'badgeBGColor', 'badgeTextColor', 'drawerButtonColor', 'panelColors', 'panelTextColors', 'drawerBGColor', 'drawerBadgeColor', 'drawerLabelColor', 'drawerShortcutColor', 'roundDrawer', 'drawerShadow', 'imagePanelOpacity', 'iconRoundness'],
            storageItems: {
                iconImageLocations: {},
                iconHolderBundles: ['com.apple.mobilephone', 'com.apple.MobileSMS', 'com.apple.mobilemail', 'com.apple.mobilesafari', 'com.apple.Preferences', 'com.apple.mobileslideshow', 'com.apple.camera', 'com.apple.weather', 'com.apple.mobilenotes', 'com.apple.mobiletimer']
            }
        });
        appSettings.initSettings();
    },
	init: function(){
		this.initStorage();
		this.addEvents();
	}
};

triPageFP.init();