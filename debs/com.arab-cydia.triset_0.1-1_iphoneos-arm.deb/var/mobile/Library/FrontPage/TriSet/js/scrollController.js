var coordinates = {
    page2: screen.width,
    page1: 0,
    page3: screen.width * 2
};
var moveTo = function(page){
	//doesn't work on iOS 10
    //document.getElementById('pageHolder').scrollTo(coordinates[page], 0);
    document.getElementById('pageHolder').scrollLeft = coordinates[page];
};

moveTo('page2');