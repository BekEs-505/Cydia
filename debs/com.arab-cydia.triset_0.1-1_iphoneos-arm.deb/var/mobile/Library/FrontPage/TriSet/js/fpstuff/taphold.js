/* 
	tapHold mini library

****** Usage *****

	taphold({
	    time: 400,
	    element: document.getElementById('start'),
	    action: function(element){
	    	alert('you held on this element for 400ms ' + element);
	    },
        passTarget: true
	});

	https://junesiphone.com
*/

(function(){
	var taphold = function (t) {
        	var tapTimer = null;
        	if(!t){console.log("This method takes an object"); return;}
        	t.element.addEventListener('touchstart', function(e){
        		tapTimer = setTimeout(function(){
        			if(t.passTarget){
        				t.action(e.target);
        			}else{
        				t.action();
        			}
        		}, t.time);
        	});
        	t.element.addEventListener('touchend', function(){
        		clearTimeout(tapTimer);
        	});
        	t.element.addEventListener('touchcancel', function(){
        		clearTimeout(tapTimer);
        	});
        };
    window.taphold = taphold;
}());


/*
    Usage:
        tripleTap({
            div: document.querySelector('.mnml'),
            callback: function(){
                document.getElementById('jSettings').style.display = "block";
            }
        });
*/

(function(){
    var taps = 0, 
        tapTimer = null,
        clearTap = function(){
            taps = 0;
            clearTimeout(tapTimer); 
            tapTimer = null;
        },
        tripleTap = function(obj){
            obj.div.addEventListener('touchstart', function(e){
                if(e.touches.length > 1){
                    clearTap();
                    return;
                }
                taps = taps + 1;
                if(tapTimer === null){
                    tapTimer = setTimeout(function(){
                        clearTap();
                    }, 600)
                }
            });
            obj.div.addEventListener('touchmove', function(){
                clearTap();
            });
            obj.div.addEventListener('touchend', function(){
                if(taps === 3){
                    setTimeout(function(){
                        obj.callback();
                    }, 0);
                    clearTap();                    
                }
            });
            obj.div.addEventListener('touchcancel', function(){
                clearTap();
            });
        };
    window.tripleTap = tripleTap;
}());
