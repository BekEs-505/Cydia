var FPI = {},
    createDrawer,
    startClock,
    openApp,
    appsInstalled,
    setFPIInfo,
    FPIloaded,
    loadApps,
    loadMusic,
    badgeUpdated,
    loadBattery,
    loadStatusBar,
    loadSystem,
    loadSwitcher,
    loadNotifications,
    loadFolders,
    loadAlarms,
    loadWeather,
    loadMemory,
    deviceUnlocked,
    selectedImageFromFP,
    selectedImageFromFPCanceled,
    wifiBars = [0, 5, 10, 15],
    signalBars = [100, 76, 52, 28, 0];

createDrawer = function() {
    var iconW = 11,
        iconM = 25,
        pagingAmount = 20;
    // iPhone X
    if (window.innerHeight == 812) {
        iconW = 12;
        iconM = 15;
        pagingAmount = 32;
    }
    // iPhone 7
    if (window.innerHeight == 667) {
        iconW = 11;
        iconM = 23;
        pagingAmount = 20;
    }
    // iPhone 5, 5s, SE
    if (window.innerHeight == 568) {
        iconW = 10;
        iconM = 20;
        pagingAmount = 20;
    }
    FPI.drawer = new Drawer({
        labels: true,
        idPrefix: "APP",
        pagingAmount: pagingAmount,
        iconWidth: iconW,
        iconMargin: iconM,
        pageSpacing: 20,
        pagePadding: 10,
        labelTopPadding: 1,
    });
};
startClock = function(){
    clock({
    twentyfour : (FPI.system.twentyfour == "yes") ? true : false,
    padzero : true,
    refresh : 1000,
    success: function(clock){
      document.getElementById('time').innerHTML = clock.hour() + ":" + clock.minute();
    }
  });
};
openApp = function(bundle) {
    if (bundle === 'com.junesiphone.drawer') {
        FPI.drawer.toggleDrawer();
    } else {
        window.location = 'frontpage:openApp:' + bundle;
    }
};
appsInstalled = function() {
    FPI.drawer.reloadIcons();
};
setFPIInfo = function(info, label, parse) {
    if (parse) {
        FPI[label] = JSON.parse(info);
    } else {
        FPI[label] = info;
    }
};
FPIloaded = function() {
    createDrawer();
    startClock();
    try{
                            triPageFP.loadSavedApps();
                        }catch(err){
                            alert(err);
                        }
    //triPageFP.loadSavedApps();
};
badgeUpdated = function(bundle) {
    FPI.drawer.updateBadge(bundle);
    if(document.getElementById(bundle)){
        if(FPI.bundle[bundle].badge > 0){
            document.getElementById(bundle).innerHTML = "<div class='badge'>" + FPI.bundle[bundle].badge + "</div>";
        }else{
            document.getElementById(bundle).innerHTML = "";
        }
    }
};
// setTimeout(function(){
//     console.log('updated');
//     badgeUpdated('com.apple.mobilephone');
// },2000);
loadBattery = function() {
    document.getElementById('batteryPercent').innerHTML = "Battery is at " + FPI.battery.percent + "%";
};
selectedImageFromFP = function(img){
  lStorage.replaceIconLocation('iconImageLocations', triPageFP.target.getAttribute('bundle'), img);
  triPageFP.loadSavedApps();
  triPageFP.changingIcon = false;
  triPageFP.changingApp = false;
};
selectedImageFromFPCancelled = function(){
  triPageFP.changingIcon = false;
  triPageFP.changingApp = false;
};
loadStatusBar = function() {
    // var wifiState,
    //     wifiDIV = document.getElementById('service');
    //   if(FPI.statusbar.wifiName === "NA"){
    //     wifiState = "";
    //     wifiState = "url('src/css/service/signal" + FPI.statusbar.signalBars + ".png')";
    //   }else{
    //     wifiState = "";
    //     wifiState = "url('src/css/service/wifi" + FPI.statusbar.wifiBars + ".png')";
    //   }
    //   wifiDIV.style.backgroundImage = wifiState;
};
loadMusic = function(){
    var title = document.getElementById('title'),
    artist = document.getElementById('artist'),
    image = document.querySelector('.thirdCenterContainer'),
    musicText = document.getElementById('musicText'),
    playButton = document.getElementById('play');
  if(FPI.music.isPlaying){
    if(FPI.music.albumArt){
        image.style.backgroundImage = "url('" + FPI.music.albumArt + "')";
    }
    title.innerHTML = (FPI.music.title === "(null)") ? "Loading" : FPI.music.title;
    artist.innerHTML = (FPI.music.artist === "(null)") ? "Loading" : FPI.music.artist;
    play.innerHTML = "X";
    musicText.innerHTML = "Music playing";
  }else{
    image.style.backgroundImage = "url('css/images/img3.jpg')";
    play.innerHTML = "x";
    musicText.innerHTML = "Music stopped";
  }
};
loadSystem = function() {};
loadSwitcher = function() {};
loadNotifications = function() {};
loadFolders = function() {};
loadAlarms = function() {};
loadWeather = function() {
    var weather = FPI.weather;
    document.getElementById('temp').innerHTML = weather.temperature + "&deg;";
    for (var i = 0; i < forecastDayCount; i++) {
        var icon = weather.dayForecasts[i].icon;
        var dlow = weather.dayForecasts[i].low;
        var dhigh = weather.dayForecasts[i].high;
        var dofw = weather.dayForecasts[i].dayOfWeek - 1;
        icon = (weather.dayForecasts[i].icon == 3200) ? weather.conditionCode : weather.dayForecasts[i].icon;
        document.getElementById('weatherIcons' + i).src = 'icons/' + icon + '.png';
        document.getElementById('weatherDays' + i).innerHTML = translate[current].sday[dofw];
        document.getElementById('weatherTemps' + i).innerHTML = dhigh + '/' + dlow;
    }
    document.getElementById('lastupdated').innerHTML = "Last Updated: " + weather.updateTimeString;
};
loadMemory = function() {};
deviceUnlocked = function() {};
loadApps = function() {};