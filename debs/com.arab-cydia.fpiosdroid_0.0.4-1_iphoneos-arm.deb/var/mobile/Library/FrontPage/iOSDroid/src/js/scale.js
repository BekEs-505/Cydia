//Decided to go this route as css media queries weren't good enough for users using upscale
var scale = 1;
switch (screen.width) {
case 375:
    scale = 0.906;
    break;
case 414:
    scale = 1;
    break;
case 425:
    scale = 1.03;
    break;
case 320:
    scale = 0.77299;
    break;
}
document.body.style.webkitTransform = "scale(" + scale + ")";
