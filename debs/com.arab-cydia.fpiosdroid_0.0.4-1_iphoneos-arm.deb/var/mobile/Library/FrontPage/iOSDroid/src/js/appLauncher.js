/*jslint
  node: true,
  sloppy: true,
  browser: true
*/
/*global
  favInfo:true,
  appInfo,
  blacklist,
  drawer,
  appBundles,
  swiper,
  alert,
  grid,
  FPI,
  confirm,
  openApp
*/
/*

   ___                      ______
  |_  |                     |  _  \
    | |_   _ _ __   ___  ___| | | |_ __ __ ___      _____ _ __
    | | | | | '_ \ / _ \/ __| | | | '__/ _` \ \ /\ / / _ \ '__|
/\__/ / |_| | | | |  __/\__ \ |/ /| | | (_| |\ V  V /  __/ |
\____/ \__,_|_| |_|\___||___/___/ |_|  \__,_| \_/\_/ \___|_|

Copyright (C) 2017 JunesiPhone. All Rights Reserved.

App drawer to use with FrontPage reads applist from iOS device.
Drawer contains app icons, labels, and badges. Scrollable lists.
User can make favorites, view only by notifications, and choose two view options.
Created and maintained by @JunesiPhone http://junesiphone.com

*/
'use strict';

/* Add move option to array */
Array.prototype.move = function (from_index, to_index) {
    var x = this[from_index];
    this.splice(from_index, 1);
    this.splice(to_index, 0, x);
    return this;
};
Array.prototype.contains = function (obj) {
    return this.indexOf(obj) > -1;
};

var grid = true,
    appDrawer = {
        inEditMode: false,
        inFavorites: false,
        drawerScrolling: false,
        favoriteArray: [],
        appInfo: [],
        favInfo: [],
        touchTimer: false,
        timerFired: false,
        touchedApp: "",
        iconContainer: document.getElementById('iconContainer'),
        favButton: document.getElementById('fav'),
        allButton: document.getElementById('all'),
        moreButton: document.getElementById('more'),
        editText: document.getElementById('edit'),
        cache: {},
        clearDiv: function (divID) {
            var div = document.getElementById(divID);
            while (div.firstChild) {
                div.removeChild(div.firstChild);
            }
        },
        loadCss: function () {
            if (grid) {
                var cssFile = document.createElement("link");
                cssFile.setAttribute("rel", "stylesheet");
                cssFile.setAttribute("type", "text/css");
                cssFile.setAttribute("href", 'src/css/gridDrawer.css');
                document.getElementsByTagName("head")[0].appendChild(cssFile);
            }
        },
        searchApp: function () {
            var input, filter, ul, li, a, i;
            input = document.getElementById('newSearch');
            filter = input.value.toUpperCase();
            ul = document.getElementById("iconContainer");
            li = ul.getElementsByTagName('li');

            for (i = 0; i < li.length; i += 1) {
                a = li[i].getAttribute('tag');
                if (a.toUpperCase().indexOf(filter) > -1) {
                    li[i].style.display = "";
                } else {
                    li[i].style.display = "none";
                }
            }
        },
        showDrawer: function () {
            //document.getElementById('appDrawerDiv').style.top = '0px';
            document.getElementById('appDrawerDiv').style.webkitTransform = "translate(0,-100%)";
        },
        toggleButton: function (button) {
            var fav, all, more, edit;
            if (button === 'all') {
                fav = 'inactiveButton';
                all = 'activeButton';
                more = 'inactiveButton';
                edit = '1';
            } else if (button === 'fav') {
                fav = 'activeButton';
                all = 'inactiveButton';
                more = 'inactiveButton';
                edit = 'Z';
            } else if (button === 'more') {
                fav = 'inactiveButton';
                all = 'inactiveButton';
                more = 'activeButton';
                edit = '1';
            }
            appDrawer.favButton.className = fav;
            appDrawer.allButton.className = all;
            appDrawer.moreButton.className = more;
            appDrawer.editText.innerHTML = edit;
        },
        checkBundle: function (bundle) {
            /* Fixes for icon images */
            if (bundle === 'com.agilebits.onepassword') {
                bundle = 'com.agilebits.onepassword-ios';
            }
            if (bundle === 'com.groupme.iphone') {
                bundle = 'com.groupme.iphone-app';
            }
            if (bundle === 'com.cn') {
                bundle = 'com.cn-rulez.Blurify';
            }
            if (bundle === 'crash') {
                bundle = 'crash-reporter';
            }
            if (bundle === 'com.filippobiga.springtomize3') {
                bundle = 'com.filippobiga.springtomize3-app';
            }
            return bundle;
        },
        checkApp: function (app) {
            /* fixes for icon bundles (to open the app) */
            if (app === 'com.agilebits.onepassword') {
                app = 'com.agilebits.onepassword-ios';
            }
            if (app === 'com.groupme.iphone') {
                app = 'com.groupme.iphone-app';
            }
            return app;
        },
        getAppIcon: function (bundle) {
            try {
                if (bundle) {
                    return '/var/mobile/Library/FrontPageCache/' + appDrawer.checkBundle(bundle) + '.png';
                }
                return 0;
            } catch (err) {
                return 0;
            }
        },
        getNotificationCount: function (bundle) {
            try {
                if (bundle) {
                    return FPI.bundle[appDrawer.checkBundle(bundle)].badge;
                }
                return 0;
            } catch (err) {
                return 0;
            }
        },
        showEditFav: function (nohide) {
            var selectors = document.getElementsByClassName('check'),
                i;
            for (i = 0; i < selectors.length; i += 1) {
                if (selectors[i].title === 'inFav') {
                    selectors[i].className += ' checked';
                } else {
                    selectors[i].className += ' notChecked';
                }
                if (nohide) {
                    selectors[i].style.display = 'block';
                } else {
                    selectors[i].style.display = 'none';
                }
            }
        },
        showEditApp: function () {
            var sheet = document.createElement('style');
            if (this.inEditMode) {
                sheet.innerHTML = ".moveup, .movedown{display:block;}";
            } else {
                sheet.innerHTML = ".moveup, .movedown{display:none;}";
            }
            document.body.appendChild(sheet);
        },
        editMode: function (nohide) {
            if (this.inFavorites) {
                this.showEditApp(); //edit the app in Favorites
            } else {
                this.showEditFav(nohide); //add apps to favorites
            }
        },
        saveLocal: function (bundle, name, save) {
            if (save) {
                this.favoriteArray.push(bundle + '~' + name);
            } else {
                var e = this.favoriteArray.indexOf(bundle + '~' + name);
                if (e !== -1) {
                    this.favoriteArray.splice(e, 1);
                }
            }
            localStorage.appLauncher = JSON.stringify(this.favoriteArray);
        },
        /*
                    confusing...
                    <li>
                    <div class="iconHolder">
                        <img />
                        <label></label>
                        <span class="check"></span> //or class="check checked"
                        <span class="movedown"></span>
                        <span class="moveup"></span>
                        <span class="drawerBadges"></span>
                    </div>
                    </li>
                    //this is for addToStorage and removeFromStorage.
         */
        addToStorage: function (span, bundle, name) {
            span.setAttribute('title', 'inFav');
            span.className = 'check'; //span sent is the class="check" or class="check notChecked"
            this.saveLocal(bundle, name, true);
        },
        removeFromStorage: function (span, bundle, name) {
            span.setAttribute('title', 'null');
            span.parentElement.children[0].style.opacity = 0.2; //the span is class="check notChecked" the parent is <div> first child is icon
            span.className = 'check notChecked';
            this.saveLocal(bundle, name, false);
        },
        onload: function () {
            var storage = JSON.parse(localStorage.appLauncher),
                i,
                c;
            if (storage) {
                for (i = 0; i < storage.length; i += 1) {
                    c = document.getElementById(storage[i].split('~')[0]);
                    if (c !== null) {
                        c.children[0].children[2].setAttribute('title', 'inFav');
                    }
                }
            }
        },
        moveItem: function (pos, el) {
            var bundle, name, e;
            bundle = el.parentNode.parentNode.id;
            name = el.parentNode.parentNode.getAttribute('tag');
            e = this.favoriteArray.indexOf(bundle + '~' + name);
            if (pos === 'up') {
                if ((e - 1) >= 0) {
                    this.favoriteArray.move(e, e - 1);
                }
            } else {
                if ((e + 1) <= this.favoriteArray.length - 1) {
                    this.favoriteArray.move(e, e + 1);
                }
            }
            localStorage.appLauncher = JSON.stringify(this.favoriteArray);
            this.favApps();
            this.inEditMode = true;
        },
        createItemForLauncher: function (name, bundle) {
            var li, div, img, label, span, span1, span2, badge, badgespan;
            badge = appDrawer.getNotificationCount(bundle);
            li = document.createElement('li');
            div = document.createElement('div');
            img = document.createElement('img');
            label = document.createElement('label');
            span = document.createElement('span');
            span1 = document.createElement('span');
            span2 = document.createElement('span');
            badgespan = document.createElement('span');
            span1.innerHTML = 'l';
            span2.innerHTML = 'x';
            badgespan.innerHTML = (badge > 0) ? badge : '';
            badgespan.className = 'drawerBadges';
            badgespan.id = "badgeID" + bundle;
            span1.className = 'movedown';
            span2.className = 'moveup';
            span1.setAttribute('title', 'down');
            span2.setAttribute('title', 'up');
            span.innerHTML = "9";
            span.className = 'check';
            img.src = '/var/mobile/Library/FrontPageCache/' + appDrawer.checkBundle(bundle) + '.png';
            label.innerHTML = name;
            div.className = 'iconHolder';
            li.setAttribute('title', bundle);
            li.setAttribute('tag', name);
            li.id = bundle;
            div.appendChild(img);
            div.appendChild(label);
            div.appendChild(span);
            div.appendChild(span1);
            div.appendChild(span2);
            div.appendChild(badgespan);
            li.appendChild(div);
            this.iconContainer.appendChild(li);
        },
        hideFavs: function () {
            var sheet;
            sheet = document.createElement('style');
            sheet.innerHTML = ".moveup, .movedown{display:none;}";
            document.body.appendChild(sheet);
            this.inEditMode = false;
            this.inFavorites = false;
        },
        allApps: function () {
            var i,
                contents;
            appDrawer.toggleButton('all');
            this.hideFavs();
            this.clearDiv('iconContainer');
            this.inFavorites = false;
            this.inEditMode = false;
            for (i = 0; i < appDrawer.appInfo.length; i += 1) {
                contents = appDrawer.appInfo[i].split('~');
                this.createItemForLauncher(contents[0], contents[1]);
            }
            this.onload();
        },
        savedLocalStorage: function () {
            if (localStorage.appLauncher !== null && localStorage.appLauncher !== undefined && localStorage.appLauncher !== 'null' && localStorage.appLauncher !== 'undefined') {
                return true;
            }
            return false;
        },
        getFavList: function (bundle, name) {
            this.favInfo.push(name + '~' + bundle);
        },
        favApps: function () {
            var storage, i, e, name, bundle;
            appDrawer.toggleButton('fav');
            this.inFavorites = true;
            appDrawer.favInfo = [];
            this.clearDiv('iconContainer');
            this.inEditMode = false;

            if (this.savedLocalStorage()) {
                storage = JSON.parse(localStorage.appLauncher);
                if (storage) {
                    for (i = 0; i < storage.length; i += 1) {
                        appDrawer.getFavList(storage[i].split('~')[0], storage[i].split('~')[1]);
                    }
                    for (e = 0; e < appDrawer.favInfo.length; e += 1) {
                        name = appDrawer.favInfo[e].split('~')[0];
                        bundle = appDrawer.favInfo[e].split('~')[1];
                        this.createItemForLauncher(name, bundle);
                    }
                }
            }
        },
        moreApps: function () {
            var i,
                name,
                bundle,
                badge;
            appDrawer.toggleButton('more');
            this.hideFavs();
            this.clearDiv('iconContainer');
            this.inFavorites = false;
            this.iconContainer.innerHTML = '';
            this.inEditMode = false;
            for (i = 0; i < appDrawer.appInfo.length; i += 1) {
                name = appDrawer.appInfo[i].split('~')[0];
                bundle = appDrawer.appInfo[i].split('~')[1];
                badge = appDrawer.appInfo[i].split('~')[2];
                if (appDrawer.getNotificationCount(bundle) >= 1) {
                    this.createItemForLauncher(name, bundle);
                }
            }
        },
        clearBlacklist: function () {
            localStorage.removeItem('blacklist');
            appDrawer.refreshApps();
            appDrawer.allApps();
        },
        refreshApps: function () {
            var applications = FPI.apps.all,
                i,
                displayNames,
                bundle;
            this.appInfo = [];
            for (i = 0; i < applications.length; i += 1) {
                displayNames = applications[i].name;
                bundle = applications[i].bundle;
                if (!blacklist.contains(bundle)) {
                    this.appInfo.push(displayNames + '~' + bundle);
                }
            }
            this.appInfo.sort();
        },
        initializeAppDrawer: function () {
            try {
                appDrawer.loadCss();
                appDrawer.refreshApps();
                if (this.savedLocalStorage()) {
                    var storage = JSON.parse(localStorage.appLauncher),
                        i;
                    if (storage) {
                        for (i = 0; i < storage.length; i += 1) {
                            appDrawer.favoriteArray.push(storage[i]); //push back to local array
                        }
                    }
                }
                appDrawer.allApps();
            } catch (err) {
                //alert("Error initializing AppDrawer: " + err);
            }
        }
    };

/* TESTING ONLY THIS IS NOT NEEDED */
/***********************************/
/***********************************/
/***********************************/
/***********************************/
appDrawer.createTestIconForLauncher = function (name, bundle) {
    var icon = 'testIcon.png',
        li,
        div,
        img,
        label,
        span,
        span1,
        span2,
        badge,
        badgespan,
        doc = document;
    badge = '10';
    li = doc.createElement('li');
    div = doc.createElement('div');
    img = doc.createElement('img');
    label = doc.createElement('label');
    span = doc.createElement('span');
    span1 = doc.createElement('span');
    span2 = doc.createElement('span');
    badgespan = doc.createElement('span');
    span1.innerHTML = 'l';
    span2.innerHTML = 'x';
    badgespan.innerHTML = (badge > 0) ? badge : '';
    badgespan.className = 'drawerBadges';
    span1.className = 'movedown';
    span2.className = 'moveup';
    span1.setAttribute('title', 'down');
    span2.setAttribute('title', 'up');
    span.innerHTML = "9";
    span.className = 'check';
    label.innerHTML = name;
    div.className = 'iconHolder';
    li.setAttribute('title', bundle);
    li.setAttribute('tag', name);
    li.id = bundle;
    div.appendChild(img);
    div.appendChild(label);
    div.appendChild(span);
    div.appendChild(span1);
    div.appendChild(span2);
    div.appendChild(badgespan);
    li.appendChild(div);
    img.src = icon;
    this.iconContainer.appendChild(li);

};
appDrawer.loadTestCss = function (layout) {
    if (layout === 'grid') {
        var cssFile = document.createElement("link"),
            css = layout;
        cssFile.setAttribute("rel", "stylesheet");
        cssFile.setAttribute("type", "text/css");
        cssFile.setAttribute("href", 'src/css/' + css + 'Drawer.css');
        document.getElementsByTagName("head")[0].appendChild(cssFile);
    }
};

function testDrawer(layout) {
    var apps = 20,
        i;
    document.getElementById('appDrawerDiv').style.top = '0px';
    for (i = 0; i < apps; i += 1) {
        appDrawer.createTestIconForLauncher("AppStore" + i, "AppStore" + i);
    }
    appDrawer.loadTestCss(layout);

}
//testDrawer('grid'); //with grid
//testDrawer(); without

/************************/
/************************/
/************************/
/************************/
/*END OF TESTING STUFFS*/



/* Events used to control the appDrawer */
appDrawer.iconContainer.addEventListener('touchmove', function () {
    appDrawer.drawerScrolling = true;
});

//not implemented

// appDrawer.iconContainer.addEventListener('touchstart', function (e) {
//     appDrawer.touchedApp = e.target.title;
//     appDrawer.touchTimer = setTimeout(function () {
//         appDrawer.timerFired = true;
//         var cfrm = "Do you wish to hide this app " + appDrawer.touchedApp,
//             ifOK = confirm(cfrm);
//         if (ifOK) {
//             if (appDrawer.touchedApp === 'com.agilebits.onepassword-ios' || appDrawer.touchedApp === 'com.agilebits.onepassword') {
//                 blacklist.push('com.agilebits.onepassword');
//                 blacklist.push('com.agilebits.onepassword-ios');
//             } else {
//                 blacklist.push(appDrawer.touchedApp);
//             }
//             localStorage.blacklist = JSON.stringify(blacklist);
//             appDrawer.refreshApps();
//             appDrawer.allApps();
//             alert("App Removed, to clear all removed hold down on the x");
//         }
//     }, 2000);
// });
appDrawer.iconContainer.addEventListener('touchend', function (e) {
    var span, search;
    clearTimeout(appDrawer.touchTimer);
    if (!appDrawer.drawerScrolling) {
        if (appDrawer.inEditMode) {
            if (appDrawer.inFavorites) {
                if (e.target.title === 'up' || e.target.title === 'down') {
                    appDrawer.moveItem(e.target.title, e.target);
                }
            } else {
                /*
                    confusing...
                    <li>
                    <div class="iconHolder">
                        <img />
                        <label></label>
                        <span class="check"></span> //or class="check checked"
                        <span class="movedown"></span>
                        <span class="moveup"></span>
                        <span class="drawerBadges"></span>
                    </div>
                    </li>
                */
                span = e.target.children[0].children[2]; //li first child which is the div, second child in div is the check.
                if (span.title === 'inFav') {
                    appDrawer.removeFromStorage(e.target.children[0].children[2], e.target.title, e.target.getAttribute('tag'));
                } else {
                    appDrawer.addToStorage(e.target.children[0].children[2], e.target.title, e.target.getAttribute('tag'));
                }
            }
        } else {
            if (e.target.title !== 'search') {
                search = document.getElementById('newSearch');
                search.value = '';
                search.blur();
                appDrawer.searchApp();
                openApp(appDrawer.checkApp(e.target.title));
                setTimeout (function () {
                    //document.getElementById('appDrawerDiv').style.top = '100%';
                    document.getElementById('appDrawerDiv').style.webkitTransform = "translate(0,100%)";
                }, 1000);
            }
        }
    }
    appDrawer.drawerScrolling = false;
});
appDrawer.handleOptionTouches = function (id) {
    switch (id) {
    case 'all':
        appDrawer.allApps();
        break;
    case 'fav':
        appDrawer.favApps();
        break;
    case 'more':
        appDrawer.moreApps();
        break;
    case 'close':
        //document.getElementById('appDrawerDiv').style.top = '100%';
        document.getElementById('appDrawerDiv').style.webkitTransform = "translate(0,100%)";
        break;
    case 'edit':
        if (!appDrawer.inEditMode) {
            appDrawer.inEditMode = true;
            appDrawer.editMode(true);
        } else {
            appDrawer.inEditMode = false;
            appDrawer.editMode(false);
        }
        break;
    case 'newSearch':
        document.getElementById('newSearch').focus();
        break;
    }
};
document.getElementById('appOptions').addEventListener('touchstart', function (e) {
    e.preventDefault();
    appDrawer.handleOptionTouches(e.target.id);
});

//not implemented

// document.getElementById('close').addEventListener('touchstart', function () {
//     appDrawer.touchTimer = setTimeout(function () {
//         appDrawer.timerFired = true;
//         var cfrm = "Do you wish to show all hidden apps? ",
//             ifOK = confirm(cfrm);
//         if (ifOK) {
//             blacklist = [];
//             localStorage.removeItem('blacklist');
//             appDrawer.refreshApps();
//             appDrawer.allApps();
//         }
//     }, 2000);
// });
// document.getElementById('close').addEventListener('touchend', function () {
//     clearTimeout(appDrawer.touchTimer);
//     appDrawer.timerFired = false;
//     document.getElementById('appDrawerDiv').style.left = 800;
// });