/* Copyright © 0neguy Inc. 2018 */
/* Credits to twitter.com/notdanieldev, for icons! */

var $ = document;

var pause = '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" style="isolation:isolate" viewBox="0 0 83.3 83.3" width="83.3" height="83.3"> <g clip-path="url(#_clipPath_KMyqJzuYo5bx8knxir4GpWx2AhWpiLEO)"> <g> <rect x="11.3" y="4.687" width="18.558" height="73.926" transform="matrix(1,0,0,1,0,0)" fill="rgb(0,0,0)"/> <rect x="53.442" y="4.687" width="18.558" height="73.926" transform="matrix(1,0,0,1,0,0)" fill="rgb(0,0,0)"/> </g> </g></svg>'
var play = '<svg width="83.3" height="83.3" viewBox="0 0 317 338" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"> <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"> <g id="play" fill="#000000" fill-rule="nonzero"> <rect id="Rectangle-path" x="0.083" y="0" width="60.333" height="338"></rect> <rect id="Rectangle-path" x="37.792" y="18.167" width="82.958" height="301.667"></rect> <rect id="Rectangle-path" x="113.208" y="48.333" width="67.875" height="241.333"></rect> <rect id="Rectangle-path" x="150.917" y="78.5" width="90.5" height="181"></rect> <rect id="Rectangle-path" x="210.5" y="116.833" width="75.417" height="104.333"></rect> <rect id="Rectangle-path" x="241" y="142.583" width="75.417" height="53"></rect> </g> </g></svg>'
var previous = '<svg width="83.3" height="83.3" viewBox="0 0 389 272" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"> <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"> <g id="previous" transform="translate(27.000000, 0.000000)" fill="#000000" fill-rule="nonzero"> <rect id="Rectangle-path" x="181" y="0.25" width="45.25" height="271.5"></rect> <rect id="Rectangle-path" x="135.75" y="22.875" width="62.219" height="226.25"></rect> <rect id="Rectangle-path" x="90.5" y="45.5" width="50.906" height="181"></rect> <rect id="Rectangle-path" x="45.25" y="68.125" width="67.875" height="135.75"></rect> <rect id="Rectangle-path" x="0" y="90.75" width="56.563" height="90.5"></rect> <rect id="Rectangle-path" x="316.75" y="0.25" width="45.25" height="271.5"></rect> <rect id="Rectangle-path" x="271.5" y="22.875" width="62.219" height="226.25"></rect> <rect id="Rectangle-path" x="226.25" y="45.5" width="50.906" height="181"></rect> </g> <rect id="Rectangle-path" fill="#000000" fill-rule="nonzero" x="0" y="110" width="75.417" height="53"></rect> </g> </svg>'
var skip = '<svg width="83.3" height="83.3" viewBox="0 0 389 272" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"> <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"> <g id="previous" transform="translate(194.500000, 136.000000) scale(-1, -1) translate(-194.500000, -136.000000) " fill="#000000" fill-rule="nonzero"> <rect id="Rectangle-path" x="208" y="0.25" width="45.25" height="271.5"></rect> <rect id="Rectangle-path" x="162.75" y="22.875" width="62.219" height="226.25"></rect> <rect id="Rectangle-path" x="117.5" y="45.5" width="50.906" height="181"></rect> <rect id="Rectangle-path" x="72.25" y="68.125" width="67.875" height="135.75"></rect> <rect id="Rectangle-path" x="27" y="90.75" width="56.563" height="90.5"></rect> <rect id="Rectangle-path" x="343.75" y="0.25" width="45.25" height="271.5"></rect> <rect id="Rectangle-path" x="298.5" y="22.875" width="62.219" height="226.25"></rect> <rect id="Rectangle-path" x="253.25" y="45.5" width="50.906" height="181"></rect> <rect id="Rectangle-path" x="0" y="110" width="75.417" height="53"></rect> </g> </g> </svg>'

setTimeout(function() {
    $.getElementById("previousBox").innerHTML = previous;
    $.getElementById("skipBox").innerHTML = skip;
}, 5000)

$.addEventListener("touchstart", function() {},false);

setInterval(function() {
    update();
}, 10)

function init() {
    prefs()
}

function update() {
    if (showArtist === 1 && showSong === 1) {
        $.getElementById("song").innerHTML = artist + " - " + title;
        Playing()

    } else if (showArtist === 0 && showSong === 1) {
        $.getElementById("song").innerHTML =  title;
        Playing()
    } else if (showArtist === 1 && showSong === 0) {
        $.getElementById("song").innerHTML = artist;
        Playing()
    } else if (showArtist === 0 && showSong === 0) {
        $.getElementById("song").innerHTML = "";
        Playing()
    } else {
        Playing()
    }
}

function prefs() {
    $.getElementById("song").style.fontSize = songSize;
    $.getElementById("mainBox").style.transform = "scale(" + widgetSize + ")";
    $.body.innerHTML += "<style>rect, .song{fill:" + iconHex + ";color:" + textHex + ";}</style>";
    $.getElementById("mainBox").style.width = customWidth;
    $.getElementById("mainBox").style.marginLeft = "-" + customWidth / 2 + "px";
    $.body.innerHTML += "<style>.innerBoxes{margin-left:" + iconMargin + "px;" + "margin-right:" + iconMargin + "px;}</style>";
    if (showArtist === 0 && showSong === 0) {
        $.getElementById("mainBox").style.height = "85px";
        $.body.innerHTML += "<style>margin-top:0px</style>";
    }
    if (showBox === 1) {
        $.getElementById("mainBox").style.background = boxHex
    } else {
        $.getElementById("mainBox").style.background = "transparent"
    }
    if (showBoxShadow === 1) {
        $.getElementById("mainBox").style.boxShadow = boxShadow
    } else {
        $.getElementById("mainBox").style.boxShadow = "none"
    }
    if (showIconShadow === 1) {
        $.body.innerHTML += "<style>.boxIcon{-webkit-filter:drop-shadow(" + iconShadow + ")}</style>";
    } else {
        // oof
    }
    if (showTextShadow === 1) {
        $.getElementById("song").style.textShadow = textShadow
    } else {
        $.getElementById("song").style.textShadow = "none"
    }

}

function Playing() {
    if (isplaying === 0) {
        $.getElementById("playBox").innerHTML = play;
        $.getElementById("playBox").style.transform = scale(0.5);
        if (showArtist === 0 && showSong === 0) {
            $.getElementById("song").innerHTML = ""
        } else {
            $.getElementById("song").innerHTML = notPlaying
        }
    } else if (isplaying === 1) {
        $.getElementById("playBox").innerHTML = pause;
        $.getElementById("playBox").style.transform = scale(0.7);
    } else {
        $.getElementById("playBox").innerHTML = play;
        $.getElementById("playBox").style.transform = scale(0.5);
        if (showArtist === 0 && showSong === 0) {
            $.getElementById("song").innerHTML = ""
        } else {
            $.getElementById("song").innerHTML = notPlaying
        }
    }
}