
var lang = "en";
var iPhoneType = "auto"; 