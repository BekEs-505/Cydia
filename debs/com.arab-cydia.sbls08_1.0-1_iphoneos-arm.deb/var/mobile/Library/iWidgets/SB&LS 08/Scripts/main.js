var updateFileTimer = "";
var obj = new Array;
var where = "";
var time_to_change_wall;
var dayhour;
var nighthour;
var ampm = true;		     // not necessary to change, the tweak changes it in settings

// Set a time out for all ajax requests, desactivate the cache.
$.ajaxSetup({timeout: 8000, cache: false}); 



function init() {
    
document.getElementById("Wallpaper").src = "Images/Wallpaper/Wall_black_"+ iPhoneType +".jpg";         

updateClock();
setInterval(updateClock, 1000);
updateWeather();

if (useExtraLocationCity == false) {
	document.getElementById("city");

document.getElementById("extraLocCity").style.display = "none";

	} else {

document.getElementById("extraLocCity");
	document.getElementById("city").style.display = "none";
	}
}







function updateClock() {
	var currentTime = new Date();
	var currentHours = currentTime.getHours();
	var currentMinutes = currentTime.getMinutes() < 10 ? '0' + currentTime.getMinutes() : currentTime.getMinutes();
	var currentSeconds = currentTime.getSeconds() < 10 ? '0' + currentTime.getSeconds() : currentTime.getSeconds();
	var currentDate = currentTime.getDate() < 10 ? '' + currentTime.getDate() : currentTime.getDate();
	time_to_change_wall = currentHours + currentMinutes/60;
	timeOfDay = ( currentHours < 12 ) ? "AM" : "PM";

	if (ampm == false) {
		timeOfDay = "";
		currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
		currentTimeString = currentHours + ":" + currentMinutes;
	} else {
		currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
//		currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
		currentHours = ( currentHours == 0 ) ? 12 : currentHours;
		currentTimeString = currentHours + ":" + currentMinutes + " " + timeOfDay;
	}
		
	document.getElementById("clock").innerHTML = currentTimeString;
	if (lang == "en") {	document.getElementById("date").innerHTML = days[currentTime.getDay()].substring(0, 3) + " " + currentDate + " " + months[currentTime.getMonth()].substring(0, 3); }
	else { document.getElementById("date").innerHTML = days[currentTime.getDay()].substring(0, 3) + " " + currentDate + " " + months[currentTime.getMonth()].substring(0, 3); }
	
	var sdegree = currentSeconds * 6;
	var srotate = "rotate(" + sdegree + "deg)";
	var negativesrotate = "rotate(" + "-" + sdegree + "deg)";
	var mdegree = currentMinutes * 6;
	var mrotate = "rotate(" + mdegree + "deg)";
	var hdegree = currentHours * 30 + (currentMinutes / 2);
	var hrotate = "rotate(" + hdegree + "deg)";
	
	$("#hourhand").css("-webkit-transform", hrotate);
	$("#minhand").css("-webkit-transform", mrotate);
    $("#sechand").css("-webkit-transform", srotate);
	
	$("#Gears1").css("-webkit-transform", srotate);
	$("#Gears2").css("-webkit-transform", negativesrotate);
	$("#Gears3").css("-webkit-transform", srotate);
	$("#Gears4").css("-webkit-transform", negativesrotate);
	$("#Gears5").css("-webkit-transform", srotate);

	// DAY OR NIGHT CHANGE
	if (dayhour != null) {
		if ((time_to_change_wall < dayhour) || (time_to_change_wall >= nighthour)) { var whereTmp = "night";	} else { var whereTmp = "day"; }
		if (whereTmp != where) { dealWithWeather(obj); } // Refresh the weather for day/night condition.
	}
}

function updateWeather() {
jQuery.get('file:///private/var/mobile/Documents/widgetweather.xml', function(data) {
//jQuery.get('widgetweather.xml',function(data) {

obj.updatetimestring = $(data).find('updatetimestring').text();

if (updateFileTimer != obj.updatetimestring) {
	obj.high = new Array;
	obj.low  = new Array;
	obj.code = new Array;
	obj.daynumber = new Array;
	obj.dayofweek = new Array;
	obj.time24hour = new Array;
	obj.htemp = new Array;
	obj.hcode = new Array;
	obj.hpop = new Array;
	obj.hwhere = new Array;

	$(data).find('currentcondition').each( function() {
		obj.city =$(this).find('name').text();
		obj.extraLocCity =$(this).find('extraLocCity').text();
		obj.state =$(this).find('state').text();
		obj.neighborhood =$(this).find('extraLocNeighborhood').text();
		obj.county =$(this).find('extraLocCounty').text();
		obj.country =$(this).find('extraLocCountry').text();
		obj.countrycode =$(this).find('extraLocCountryCode').text();
		obj.statecode =$(this).find('extraLocStateCode').text();
		obj.postalcode =$(this).find('extraLocUzip').text();
		obj.woeid = $(this).find('woeid').text();
		obj.locationid = $(this).find('locationid').text();	
		obj.temp = $(this).find('temp').text(); 
		obj.icon = $(this).find('code').text();
		obj.observationtime = $(this).find('observationtime').text();
		obj.sunset = $(this).find('sunsettime').text();
		obj.sunrise = $(this).find('sunrisetime').text();
		obj.tempUnit = $(this).find('celsius').text();
		obj.moonphase = $(this).find('moonphase').text()*1;
		obj.pressure = $(this).find('pressure').text();
		obj.humidity = $(this).find('humidity').text(); 
		obj.rising = $(this).find('rising').text()*1;		
		obj.visibility = $(this).find('visibility').text();
		obj.RealFeel = $(this).find('chill').text();
		obj.direction = $(data).find('direction').text();
		obj.windspeed = Math.round($(data).find('speed').text());
		obj.unitsdistance = $(this).find('unitsdistance').text();
		obj.unitspressure = $(this).find('unitspressure').text();
		obj.unitsspeed = $(this).find('unitsspeed').text();
		obj.unitstemperature = $(this).find('unitstemperature').text(); 
	});

	$(data).find('settings').each( function() {
		obj.timehour = $(this).find('timehour').text();
		ampm = (obj.timehour == "24h") ? false : true;	
	});

	var i=0;
	$(data).find('day').each( function() {
		obj.high[i] =$(this).find('high').text();
		obj.low[i] = $(this).find('low').text();
		obj.code[i] = $(this).find('code').text();	
		obj.daynumber[i] = $(this).find('daynumber').text();	
		obj.dayofweek[i] = $(this).find('dayofweek').text();
		i++;
	});

	var h=0;	
	$(data).find('hour').each( function() {
	obj.htemp[h] = $(this).find('temp').text();
	obj.hcode[h] = $(this).find('code').text();
	obj.hpop[h] = Math.round($(this).find('percentprecipitation').text());	
	obj.time24hour[h] = $(this).find('time24hour').text();
	h++;
	});

	updateFileTimer = obj.updatetimestring;
	dealWithWeather(obj);
}
}).fail(function() {
	document.getElementById("xmlupdate").innerHTML = "No XML file !";
});

refreshTimer = setTimeout(updateWeather, 20*1000);
}

// WORKAROUND FOR CORRECT ICONS IN ALL SITUATIONS AND TWELVE HOUR FORMAT* YOU NEED TO LEAVE THE DAY NIGHT FIX AND SUNRISE SUNSET INFORMATION IN SO ICONS DISPLAY. EVEN IF YOU DO NOT SHOW THEM IN A WIDGET

function AdjustIcon(icon, whereTmp) {
	switch(whereTmp) {
		case "day":
			if (icon == 27) { icon = 28; }
			if (icon == 29) { icon = 30; }	
			if (icon == 31) { icon = 32; }	
			if (icon == 33) { icon = 34; }
		break;
		case "night":
			if (icon == 28) { icon = 27; }
			if (icon == 30) { icon = 29; }	
			if (icon == 32) { icon = 31; }	
			if (icon == 34) { icon = 33; }
		break;
	}
	return icon;
}

function TwelveHourForecast(hour) {
	if (ampm == true) { 
		hour = parseInt(hour.split(':')[0]);
		var timeOfhour = ( hour < 12 ) ? "AM" : "PM";
		hour = ( hour > 12 ) ? hour - 12 : hour;
		hour = ( hour == 0 ) ? 12 : hour;
		hour = hour + " " + timeOfhour;
	}
	return hour;
}

function loadjscssfile(url, filename, filetype){
if (filetype=="js") {
	var fileref = document.createElement("script");
	fileref.type = "text/javascript";
	fileref.charset = "utf-8";
	fileref.src = url + "/" + filename + ".js";
 }
if (filetype=="css") {
	var fileref = document.createElement("link");
	fileref.rel = "stylesheet";
	fileref.href = url + "/" + filename + ".css";
	fileref.type = "text/css";
	fileref.media = "screen";
 }
document.getElementsByTagName("head")[0].appendChild(fileref);
}

function createjscssfile(url, filename, filetype){
if (filetype=="js") {
	var fileref = document.createElement("script");
	fileref.type = "text/javascript";
	fileref.charset = "utf-8";
	fileref.src = url + "/" + filename + ".js";
 }
if (filetype=="css") {
	var fileref = document.createElement("link");
	fileref.rel = "stylesheet";
	fileref.href = url + "/" + filename + ".css";
	fileref.type = "text/css";
	fileref.media = "screen";
 }
return fileref;
}

function replacejscssfile(url, oldfilename, newfilename, filetype){
	var targetelement = (filetype=="js")? "script" : (filetype=="css")? "link" : "none";
	var targetattr = (filetype=="js")? "src" : (filetype=="css")? "href" : "none";
	var allsuspects = document.getElementsByTagName(targetelement);
	for (var i = allsuspects.length; i>=0; i--) { 
			if (allsuspects[i] && allsuspects[i].getAttribute(targetattr)!=null && allsuspects[i].getAttribute(targetattr).indexOf(oldfilename)!=-1) {
				var newelement = createjscssfile(url, newfilename, filetype);
				allsuspects[i].parentNode.replaceChild(newelement, allsuspects[i]);
				}
		}
}

function removejscssfile(url, oldfilename, filetype) {
    var targetelement, targetattr, allsuspects;
    targetelement = (filetype == "js") ? "script" : (filetype == "css") ? "link" : "none";
    targetattr = (filetype == "js") ? "src" : (filetype == "css") ? "href" : "none";
    allsuspects = document.getElementsByTagName(targetelement);
    for (var i = allsuspects.length; i>=0; i--) {
        if (allsuspects[i] && allsuspects[i].getAttribute(targetattr)!=null && allsuspects[i].getAttribute(targetattr).indexOf(oldfilename)!=-1) {
        allsuspects[i].parentNode.removeChild(allsuspects[i]);
        }
    }
}
