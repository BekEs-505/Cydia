var snowCanvas = {
    flakeObjects: [],
    flakeCount: 50,
    canvas: document.getElementById("canvas"),
    ctx: document.getElementById("canvas").getContext("2d"),
    checkFlakeBounds: function(flake){
        if (flake.y >= this.canvas.height || flake.y <= 0 || flake.x >= this.canvas.width || flake.x <= 0) {
            this.resetFlake(flake);
        }
    },
    makeRandomFlake: function(reset){
        return {
            speed: (Math.random() * 1),
            x: Math.floor(Math.random() * this.canvas.width),
            y: (reset) ? 0 : Math.floor(Math.random() * this.canvas.height),
            velY: (Math.random() * 1) + 0.5,
            velX: 0,
            size: (Math.random() * 3) + 0.2,
            opacity: (Math.random() * 0.5) + 0.3,
        };
    },
    resetFlake: function(flake){
        var resetFlake = this.makeRandomFlake(true);
        Object.keys(resetFlake).forEach(function(key) {
            flake[key] = resetFlake[key];
        });
    },
    drawSnow: function(){
        var flake;
        snowCanvas.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        for (var i = 0; i < this.flakeCount; i++) {
            flake = this.flakeObjects[i];
            flake.velY = (flake.velY <= flake.speed) ? flake.speed : flake.velY;
            snowCanvas.ctx.fillStyle = "rgba(255,255,255," + flake.opacity + ")";
            flake.y += flake.velY;
            flake.x += flake.velX;
            this.checkFlakeBounds(flake);
            snowCanvas.ctx.beginPath();
            snowCanvas.ctx.arc(flake.x, flake.y, flake.size, 0, Math.PI * 2);
            snowCanvas.ctx.fill();
        }
        window.requestAnimationFrame(function() {
            snowCanvas.drawSnow();
        });
    },
    snow: function(){
        this.canvas.height = window.innerHeight;
        this.canvas.width = window.innerWidth;
        for (var i = 0; i < this.flakeCount; i++) {
            this.flakeObjects.push(this.makeRandomFlake());
        }
        this.drawSnow();
    }
};

snowCanvas.snow();