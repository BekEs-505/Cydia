var forecastMaker = {
 	//forecastMaker.makeForecast({
	// 	holder: document.getElementById('forecast'),
	// 	dayCount: 4, //forecast length
	// 	dayWidth: 70, //holder width
	// 	dayHeight: 60, //holder height
	// 	imgWidth: 35, //image size
	// 	font: 'Montserrat-Light',
	// 	dayTop: 0, //day position from top
	// 	tempBottom: 0, //temp position from bottom
	// 	fontSize: 10, //day text and temp size
	// 	iconURL: 'icons/',
	// 	iconsName: 'weatherIcons',
	// 	daysName: 'weatherDays',
	// 	tempsName: 'weatherTemps',
	// });
    setHolderCSS: function (holder) {
        holder.style.cssText = "display: flex;justify-content: center;";
    },
    makeForecast: function (obj) {
        var doc = document;
        for (var i = 0; i < obj.dayCount; i++) {
            var box = doc.createElement('div'),
                image = doc.createElement('img'),
                days = doc.createElement('span'),
                temps = doc.createElement('span');

            //container for elements
            box.style.cssText = "\
					position: relative;\
					width: " + obj.dayWidth + "px;\
					height: " + obj.dayHeight + "px;\
					float: left;\
					display: flex;\
		  			justify-content: center;\
		  			";

            //image element	
            image.id = obj.iconsName + i;
            image.style.cssText = "\
		  			position:absolute;\
					top:13px;\
					width: " + obj.imgWidth + "px;\
					";
            image.src = obj.iconURL + (30 + i) + ".png";
            box.appendChild(image);

            //day element
            days.innerHTML = "days";
            days.id = obj.daysName + i;
            days.style.cssText = "\
			    position:absolute;\
					color:white;\
					top:" + obj.dayTop + "px;\
					text-align:center;\
					width: " + obj.dayWidth + "px;\
					font-size:" + obj.fontSize + "px;\
					font-family:" + obj.font + ";\
					";
            box.appendChild(days);

            //temp element
            temps.innerHTML = "temps";
            temps.id = obj.tempsName + i;
            temps.style.cssText = "\
			    	position:absolute;\
					bottom:" + obj.tempBottom + "px;\
					text-align:center;\
					width: " + obj.dayWidth + "px;\
					color:white;\
					font-size:" + obj.fontSize + "px;\
					font-family:" + obj.font + ";\
					;"
            box.appendChild(temps);
            obj.holder.appendChild(box);
        }
        this.setHolderCSS(obj.holder);
        window.forecastDayCount = obj.dayCount;
    }
};