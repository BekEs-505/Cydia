var buttonArray = ['home', 'weather', 'calendar'];

function highlightButton(title) {
    for (var i = 0; i < buttonArray.length; i++) {
        if (buttonArray[i] === title) {
            document.getElementById(title).className = ' bgcolor';
            document.getElementById(title).style.color = 'black';
            document.getElementById('arrow-' + title).style.display = 'block';
            $("#" + title + "View").fadeIn();
        } else {
            document.getElementById(buttonArray[i]).className = ' ';
            document.getElementById(buttonArray[i]).style.color = '#acabab';
            document.getElementById('arrow-' + buttonArray[i]).style.display = 'none';
            $("#" + buttonArray[i] + "View").fadeOut();
        }
    }
}

function togglePages(title) {
    highlightButton(title);
}

document.querySelector('.topSelections').addEventListener('touchstart', function(el) {
    togglePages(el.target.id);
});