var FPI = {},
    createDrawer,
    startClock,
    updateMainApps,
    openApp,
    appsInstalled,
    setFPIInfo,
    FPIloaded,
    loadApps,
    loadMusic,
    badgeUpdated,
    loadBattery,
    loadStatusBar,
    loadSystem,
    loadSwitcher,
    loadNotifications,
    loadFolders,
    loadAlarms,
    loadWeather,
    loadMemory,
    deviceUnlocked,
    selectedImageFromFP,
    selectedImageFromFPCanceled,
    wifiBars = [0, 5, 10, 15],
    signalBars = [100, 76, 52, 28, 0];

createDrawer = function() {
    var iconW = 11,
        iconM = 25,
        pagingAmount = 20;
    // iPhone X
    if (window.innerHeight == 812) {
        iconW = 12;
        iconM = 15;
        pagingAmount = 32;
    }
    // iPhone 7
    if (window.innerHeight == 667) {
        iconW = 11;
        iconM = 23;
        pagingAmount = 20;
    }
    // iPhone 5, 5s, SE
    if (window.innerHeight == 568) {
        iconW = 10;
        iconM = 20;
        pagingAmount = 20;
    }
    FPI.drawer = new Drawer({
        labels: true,
        idPrefix: "APP",
        pagingAmount: pagingAmount,
        iconWidth: iconW,
        iconMargin: iconM,
        pageSpacing: 20,
        pagePadding: 10,
        labelTopPadding: 1,
    });
};
updateMainApps = function(){
  document.getElementById('phonebadge').innerHTML = FPI.bundle["com.apple.mobilephone"].badge;
  document.getElementById('smsbadge').innerHTML = FPI.bundle["com.apple.MobileSMS"].badge;
  document.getElementById('mailbadge').innerHTML = FPI.bundle["com.apple.mobilemail"].badge;
};
startClock = function(){
    clock({
    twentyfour : (FPI.system.twentyfour == "yes") ? true : false,
    padzero : true,
    refresh : 1000,
    success: function(clock){
      document.getElementById('time').innerHTML = clock.hour() + ':' + clock.minute();
      document.getElementById('date').innerHTML = translate[current].weekday[clock.day()] + ' ' + clock.date();
      document.getElementById('day').innerHTML = translate[current].weekday[clock.day()];
      document.getElementById('datestr').innerHTML = translate[current].sday[clock.day()] + ' ' + clock.date() + ', ' + translate[current].month[clock.month()] + ' ' + clock.year();
      document.getElementById('calMonth').innerHTML = translate[current].month[clock.month()] + ' ' + clock.year();
      document.getElementById('calDay').innerHTML = translate[current].weekday[clock.day()] + ' ' + clock.date();
    }
  });
};
openApp = function(bundle) {
    if (bundle === 'com.junesiphone.drawer') {
        FPI.drawer.toggleDrawer();
    } else {
        window.location = 'frontpage:openApp:' + bundle;
    }
};
appsInstalled = function() {
    FPI.drawer.reloadIcons();
};
setFPIInfo = function(info, label, parse) {
    if (parse) {
        FPI[label] = JSON.parse(info);
    } else {
        FPI[label] = info;
    }
};
FPIloaded = function() {
    createDrawer();
    updateMainApps();
    startClock();
};
loadApps = function() {};
loadMusic = function() {
    var song = document.getElementById('song'),
        play = document.getElementById('play');
    if (FPI.music.isPlaying) {
        play.innerHTML = 'u';
        song.innerHTML = FPI.music.artist + ' - ' + FPI.music.title;
    } else {
        play.innerHTML = 'r';
        song.innerHTML = "Open App";
    }
};
badgeUpdated = function(bundle) {
    FPI.drawer.updateBadge(bundle);
    updateMainApps();
};
loadBattery = function() {
    document.getElementById('battery').innerHTML = Math.round(FPI.battery.percent) + '%';
    document.getElementById('batteryinsides').style.width = Math.round((FPI.battery.percent / 100) * document.getElementById('BatteryLine').offsetWidth) + 'px';
};
loadStatusBar = function() {};
loadSystem = function() {};
loadSwitcher = function() {};
loadNotifications = function() {
    updateMainApps();
};
loadFolders = function() {};
loadAlarms = function() {};
loadWeather = function() {
    var celsius = (FPI.weather.celsius) ? "C" : "F",
        mph = (FPI.weather.celsius) ? "KPH" : "MPH";
    document.getElementById('city').innerHTML = FPI.weather.city;
    document.getElementById('temp').innerHTML = FPI.weather.temperature + "&deg;";
    document.getElementById('homeweather').innerHTML = translate[current].condition[FPI.weather.conditionCode] + ' ' + FPI.weather.temperature + "&deg;";
    document.getElementById('lohi').innerHTML = 'Hi ' + FPI.weather.high + '&deg;' + '/' + 'Low ' + FPI.weather.low;
    document.getElementById('windspeed').innerHTML = Math.round(FPI.weather.windSpeed);
    document.getElementById('windtype').innerHTML = mph;
    document.getElementById('humidity').innerHTML = Math.round(FPI.weather.humidity) + '%';
    document.getElementById('pressure').innerHTML = Math.round(FPI.weather.dewPoint);
    document.getElementById('last').innerHTML = "Last Updated: " + FPI.weather.updateTimeString;

    var dayArray = FPI.weather.dayForecasts;
    for (var i = 1; i < 5; i++) {
        document.getElementById('day' + i + 'day').innerHTML = translate[current].sday[dayArray[i].dayOfWeek - 1];
        if (dayArray[i].icon == 3200) {
            document.getElementById('day' + i + 'icon').src = "src/icons/" + FPI.weather.conditionCode + ".png";
        } else {
            document.getElementById('day' + i + 'icon').src = "src/icons/" + dayArray[i].icon + ".png";
        }
        document.getElementById('day' + i + 'temphi').innerHTML = dayArray[i].high + '&deg;';
        document.getElementById('day' + i + 'templo').innerHTML = dayArray[i].low + '&deg;';
    }
};
loadMemory = function() {};
deviceUnlocked = function() {};
selectedImageFromFP = function(img) {};
selectedImageFromFPCancelled = function() {};