
/* 
	Easy settings for users to change 
*/

var highlightColor = '#c7d84d',
	disableBatteryBar = false,
	musicApp = "com.apple.Music";



/* 
  change highlight color for multiple items
  highlight color is set in settings.js
*/

(function(){
  var sheet = document.createElement('style')
  sheet.innerHTML = ".arrow-right{border-left:8px solid " + highlightColor + ";}.arrow-left { border-right:8px solid " + highlightColor +";}.bgcolor{background-color:" + highlightColor + ";}#appcolor{color: " + highlightColor + " ;}.today{background-color: " + highlightColor + " ;}.ui-state-highlight{background-color: " + highlightColor + " ;}#accent:after{background-color: " + highlightColor + " ;}.badges div{color: " + highlightColor + " ;}#heart{color: " + highlightColor + " ;}#batteryinsides{background-color:" + highlightColor +"}";
  document.body.appendChild(sheet);
}());

/*
  disable battery bar set in settings.js  
*/

(function(){
  if(disableBatteryBar){
    document.getElementById('BatteryLine').style.display = 'none';
  }
}());