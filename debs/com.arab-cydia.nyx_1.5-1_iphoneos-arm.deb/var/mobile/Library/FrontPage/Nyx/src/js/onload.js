/*jslint
  node: true,
  sloppy: true,
  browser: true,
  todo: true
*/

/*global
  os,
  macDock,
  appDrawer,
  alert,
  iconDrawer
*/


window.onload = function () {

    var timer,
        longtouch = function () {
            //iconDrawer.forceSetIsEditing();
            //iconDrawer.closeWidget();
            if (!os.dockmoving) {
                //document.getElementById('shutdownScreen').classList.toggle('menuToggle');
            }
            timer = null;
        },
        detectLongTouch = function () {
            document.body.addEventListener('touchstart', function () {

                timer = setTimeout(longtouch, 300);

            });
            document.body.addEventListener('touchend', function () {
                if (timer) {
                    clearTimeout(timer);
                }
            });


            // os.registerEvents(document.getElementById('shutdownClose'), {
            //     event: os.handlerType(),
            //     callback: function (el) {
            //         document.getElementById('shutdownScreen').classList.toggle('menuToggle');
            //     }
            // });
            // os.registerEvents(document.getElementById('shutdownButton'), {
            //     event: os.handlerType(),
            //     callback: function (el) {
            //         iconDrawer.closeWidget();
            //     }
            // });
        };
        detectLongTouch(); //long touch on body means user wants to close. Assist iOS9 users.

    try {
        os.resizeWidget();
        os.setupLandscapeCss();

        //set user options from terminal

        //document.getElementById('avatar').src = localStorage.newImage || 'minimac.png';

        if(localStorage.newImage){
          document.getElementById('avatar').style.backgroundImage = 'url("' + localStorage.newImage + '")';
        }

        os.badgecolor(localStorage.badgeColor || 'red', true);


        if (window.disablewall === true || window.disablewall === 'true') {
            os.disablewall();
        } else {
            os.enablewall();
        }
        if(localStorage.hidepercent){
            document.getElementById('percent').style.display = 'none';
        }
        if(localStorage.bgcolor){
            document.getElementById('statusbar').style.backgroundColor = localStorage.bgcolor;
        }
        if(localStorage.hidewifi){
            document.getElementById('wifi').style.display = 'none';
        }
        if(localStorage.hidebattery){
            document.getElementById('batContainer').style.display = 'none';
        }
        if(localStorage.hidetime){
            document.getElementById('clock').style.display = 'none';
        }
        if(localStorage.widedock){
            os.getEl('dock').style.cssText = "width:100%; border-radius:0;";
        }
        if(localStorage.moredockicons){
            os.moredockicons();
        }
        if(localStorage.floatingdock){
            os.floatingdock();
        }
        if(localStorage.floatingstatusbar){
          os.floatingstatusbar();
        }
        if(localStorage.dockbgcolor){
          os.dockcolor(localStorage.dockbgcolor);
        }
        if(localStorage.dockwidth){
          os.dockwidth(localStorage.dockwidth);
        }
        if(localStorage.dockheight){
          os.dockheight(localStorage.dockheight);
        }
        if(localStorage.dockiconsize){
          os.dockiconsize(localStorage.dockiconsize);
        }
        if(localStorage.hidedivider){
          os.hidedivider();
        }
        if(localStorage.dateright){
          os.dateright();
        }
        if(localStorage.lightmode){
            os.lightmode();
        }
        if(localStorage.floatingfolder){
            os.floatingfolder();
        }
        if(localStorage.folderbg){
            os.disablefolderbg();
        }
        if(localStorage.launcherradius){
          os.launchericonradius(localStorage.launcherradius);
        }

        //os.disablewall();
    } catch (err) {
        alert("Error In onload" + err);
    }
};
