/*
    bundles can be changed
    example if you don't want to use the regular mail app you can change the bundle here and it will open the other app
*/

var blacklist = ['com.wanmei.mini.condorpp-532-8', 'com.apple.SharedWebCredentialViewService', 'com.apple.AccountAuthenticationDialog', 'com.apple.AdSheetPhone', 'com.apple.AskPermissionUI', 'com.apple.CompassCalibrationViewService', 'com.apple.CoreAuthUI', 'com.apple.DemoApp', 'com.apple.Diagnostics', 'com.apple.FacebookAccountMigrationDialog', 'com.apple.GameController', 'com.apple.HealthPrivacyService', 'com.apple.InCallService', 'com.apple.MailCompositionService', 'com.apple.MobileReplayer', 'com.apple.MusicUIService', 'com.apple.PassbookUIService', 'com.apple.PhotosViewService', 'com.apple.PreBoard', 'com.apple.PrintKit.Print-Center', 'com.apple.SiriViewService', 'com.apple.TencentWeiboAccountMigrationDialog', 'com.apple.TrustMe', 'com.apple.WebContentFilter.remoteUI.WebContentAnalysisUI', 'com.apple.WebSheet', 'com.apple.WebViewService', 'com.apple.appleaccount.AACredentialRecoveryDialog', 'com.apple.datadetectors.DDActionsService', 'com.apple.fieldtest', 'com.apple.gamecenter.GameCenterUIService', 'com.apple.iad.iAdOptOut', 'com.apple.ios.StoreKitUIService', 'com.apple.iosdiagnostics', 'com.apple.mobilesms.compose', 'com.apple.mobilesms.notification', 'com.apple.purplebuddy', 'com.apple.quicklook.quicklookd', 'com.apple.share', 'com.apple.uikit.PrintStatus', 'com.kstreich-dev.3gunrestrictor.configapp', 'com.apple.DataActivation', 'com.apple.Home.HomeUIService', 'com.apple.social.SLGoogleAuth', 'com.apple.social.SLYahooAuth', 'com.apple.SafariViewService', 'com.apple.ServerDocuments', 'com.apple.CloudKit.ShareBear', 'com.apple.StreDemoViewService', 'com.apple.Diagnostics.Mitosis', 'com.apple.appleseed.FeedbackAssistant', 'com.apple.StoreDemoViewService', 'undefined', 'com.apple.managedconfiguration.MDMRemoteAlertService'],
    appBundles = { //filled on load
        cydia: 'com.saurik.Cydia',
        appstore: 'com.apple.AppStore',
        calculator: 'com.apple.calculator',
        notes: 'com.apple.mobilenotes',
        music: 'com.apple.Music',
        youtube: 'com.google.ios.youtube',
        calendar: 'com.apple.mobilecal',
        clock: 'com.apple.mobiletimer',
        weather: 'com.apple.weather',
        health: 'com.apple.Health',
        maps: 'com.apple.Maps',
        safari: 'com.apple.mobilesafari',
        tweetbot: 'com.tapbots.Tweetbot4',
        twitter: 'com.atebits.Tweetie2',
        facebook: 'com.facebook.Facebook',
        instagram: 'com.burbn.instagram',
        photos: 'com.apple.mobileslideshow',
        photo: 'com.apple.mobileslideshow',
        phone: 'com.apple.mobilephone',
        messages: 'com.apple.MobileSMS',
        sms: 'com.apple.MobileSMS',
        mail: 'com.apple.mobilemail',
        camera: 'com.apple.camera',
        spotify: 'com.spotify.client',
        whatsapp: 'net.whatsapp.WhatsApp',
        snapchat: 'com.toyopagroup.picaboo',
        pokemongo: 'com.nianticlabs.pokemongo',
        playstation: 'com.playstation.eu.playstationadhoc',
        ifile: 'eu.heinelt.ifile',
        reddit: 'com.reddit.Reddit',
        cloudmagic: 'com.CloudMagic.Mail',
        premierleague: 'com.premierleague.main',
        slack: 'com.tinyspeck.chatlyio',
        settings: 'com.apple.Preferences'
    },
    bundleApps = { //used for faster fetching

    };


var openedApps = [],
    maxRecents = 9,
    addBundleId = function (bundle) {
        var index = openedApps.indexOf(bundle);
        if (index > -1) {
            openedApps.splice(index, 1);
        }
        openedApps.unshift(bundle);
        openedApps = openedApps.slice(0, maxRecents);
    };
