/*jslint
  node: true,
  sloppy: true,
  browser: true,
  todo: true
*/

/*global
  document,
  iconDrawer,
  appBundles,
  Slider,
  alert,
  appDrawer,
  nslog,
  include,
  os,
  bouncing
*/

/*

  Configures dock icons, this includes landscape switcher icons
  Show/Hides the appDrawerDiv via the launchpad icon
  Has global variables for easy change (terminal)

*/

//will be global for terminal use
var app2 = localStorage.app2 || appBundles.phone,
    app3 = localStorage.app3 || appBundles.messages,
    app4 = localStorage.app4 || appBundles.mail,
    app5 = localStorage.app5 || appBundles.safari,
    app6 = localStorage.app6 || appBundles.camera,
    app7 = localStorage.app7 || appBundles.clock,
    app8 = localStorage.app8 || appBundles.notes,
    app9 = localStorage.app9 || appBundles.calendar,
    app10 = localStorage.app10 || appBundles.photos,
    app11 = localStorage.app11 || appBundles.maps,
    app12 = localStorage.app12 || appBundles.music,
    app13 = localStorage.app13 || appBundles.settings,
    app14 = localStorage.app14 || appBundles.settings,
    app15 = localStorage.app15 || appBundles.settings,
    app16 = localStorage.app16 || appBundles.settings,
    app17 = localStorage.app17 || appBundles.settings,
    drawerimage = localStorage.drawerimages || 'src/images/launchpad.png',
    selectedDockIcon = null;

(function (window, doc) {
    function load_macDock() {
        var macDock = {
                cache: {}
            },
            moving = false,
            holding = false,
            holdTimer = null,
            iconOBJ = {},
            cachedThat = function (bundle) {
                var icon;
                if (macDock.cache.hasOwnProperty(bundle)) {
                    icon = macDock.cache[bundle];
                } else {
                    icon = iconDrawer.getIconImage(bundle);
                    macDock.cache[bundle] = icon;
                }
                return icon;
            },
            getSwitcher = function () {

              //   // //TODO wow. Yea fix please
                var apps = FPI.switcher.bundles,
                    i,
                    count = 0,
                    bundle,
                    icon,
                    badge,
                    stopper,
                    temp,
                    max;

                if (apps.length > 0) {

                    if (os.ipad) {
                        temp = 14;
                        max = 19;
                    } else {
                        temp = 14;
                        max = 19;
                    }

                    if (apps.length > max) {
                        stopper = max;
                    } else {
                        stopper = (apps.length + temp < max) ? apps.length + temp : max;
                    }

                    for (i = temp; i < stopper; i += 1) {
                        bundle = apps[count];
                        icon = '/var/mobile/Library/FrontPageCache/' + bundle + '.png';
                        doc.getElementById('app' + i).src = icon;
                        doc.getElementById('app' + i).setAttribute('title', bundle);
                        try {
                            badge = FPI.bundle[bundle].badge;
                            if (badge > 0) {
                                doc.getElementById('badge' + i).innerHTML = badge;
                                doc.getElementById('badge' + i).style.display = 'block';
                            } else {
                                doc.getElementById('badge' + i).style.display = 'none';
                            }

                        } catch (ignore) {
                          //alert(ignore);
                        }
                        count += 1;
                    }
                }
            },
            loadEvents = function () {
                // os.registerEvents(doc.getElementById('closer'), {
                //     event: os.handlerType(),
                //     callback: function (e) {
                //         appDrawer.toggleDrawer('close');
                //         os.unregisterEvents(doc.getElementById('closer'));
                //         e.preventDefault();
                //     }
                // });
            },
            updateBadgesForDock = function(){

              var temp = 14, i;
              for (i = 1; i < temp; i += 1) {
                var d =  doc.getElementById('app' + i).getAttribute('title');
                if(d != null && d != 'drawerIcon'){
                  var badge = FPI.bundle[d].badge;

                    if (badge > 0) {
                        doc.getElementById('badge' + i).innerHTML = badge;
                        doc.getElementById('badge' + i).style.display = 'block';
                    } else {
                        doc.getElementById('badge' + i).style.display = 'none';
                    }

                    bounceCheck = (window.bouncing === "true") ? true : (window.bouncing === true) ? window.bouncing : false;
                    if (badge > 0 && bounceCheck) {
                        doc.getElementById('app' + i).parentElement.parentElement.className = 'jump';

                    } else {
                        doc.getElementById('app' + i).parentElement.parentElement.className = '';
                    }

                }
              }

            },
            setupDock = function () {
                var src,
                    windowVar,
                    i,
                    badge,
                    bounceCheck,
                    temp,
                    z;
                // there is 6 icons in the dock that get user apps including launchpad
                // these apps variables are global
                if (os.ipad) {
                    temp = 14;
                } else {
                    temp = 14;
                }

                for (i = 1; i < temp; i += 1) {
                    windowVar = window['app' + i];
                    //iPad doesn't have phone app
                    if (os.ipad && windowVar === appBundles.phone) {
                        windowVar = appBundles.notes;
                    }
                    //skip one for launchpad icon
                    if (i !== 1) {

                        if (appDrawer.cache.hasOwnProperty(windowVar)) {
                            src = appDrawer.cache[windowVar];

                        } else {

                            for (z = 1; z < FPI.apps.all.length; z += 1) {
                              iconOBJ[FPI.apps.all[z].bundle] = FPI.apps.all[z].icon;
                                if (FPI.apps.all[z].bundle === windowVar) {
                                  //alert(JSON.stringify(FPI.system.apps[0]));
                                    src = '/var/mobile/Library/FrontPageCache/' + FPI.apps.all[z].bundle + '.png';
                                    badge = FPI.apps.all[z].badge;
                                    if (badge > 0) {
                                        doc.getElementById('badge' + i).innerHTML = badge;
                                        doc.getElementById('badge' + i).style.display = 'block';
                                    } else {
                                        doc.getElementById('badge' + i).style.display = 'none';
                                    }
                                    appDrawer.cache[windowVar] = src;
                                }
                            }
                        }

                        bounceCheck = (bouncing === "true") ? true : (bouncing === true) ? bouncing : false;
                        if (badge > 0 && bounceCheck) {
                            doc.getElementById('app' + i).parentElement.parentElement.className = 'jump';
                        } else {
                            doc.getElementById('app' + i).parentElement.parentElement.className = '';
                        }
                    } else {
                        //src = "src/images/" + drawerimage + ".png";
                        src = drawerimage;
                        //localStorage.drawerimages = drawerimage;
                        windowVar = 'drawerIcon';
                        doc.getElementById('app1').parentElement.parentElement.className = '';
                    }
                    doc.getElementById('app' + i).src = src;
                    doc.getElementById('app' + i).setAttribute('title', windowVar);
                }

                if (doc.getElementById('iWidget').className === "landscape") {
                    //getSwitcher();
                }
            };
        var startX, startY;
        os.registerEvents(doc.getElementById('dockList'), {
            event: 'touchstart',
            callback: function (el) {
              if(el.target.id === "dockList"){ //we only want the elements inside
                return;
              }
              selectedDockIcon = el.target.id;
                startX = event.touches[0].pageX;
                startY = event.touches[0].pageY;
                holdTimer = setTimeout(function(){
                  if(!moving){
                    if(selectedDockIcon === 'app1'){ //launcher icon
                        window.location = 'frontpage:loadIconBrowser';
                    }else{
                        os.popup('Change Icon: Are you sure you want to do this?', appDrawer.toggleApps, "Yes", "No", true);
                        holding = true;
                    }
                  }
                }, 2000);
            }
        });

        //dockList doesn't need to be removed
        os.registerEvents(doc.getElementById('dockList'), {
            event: 'touchmove',
            callback: function (el) {
              clearTimeout(holdTimer);
              if(el.target.id === "dockList"){//we only want the elements inside
                return;
              }
                if (el.touches[0].pageX > Number(startX + 5) || el.touches[0].pageX < Number(startX - 5)) {
                    moving = true;
                    el.target.style['-webkit-transform'] = 'scale(1.2) translate(0, -20px)';

                    if(el.touches[0].pageY > Number(startY + 20) || el.touches[0].pageY < Number(startY - 20)){
                      el.target.style['-webkit-transform'] = 'scale(1) translate(0, 0px)';
                    }
                }
            }
        });


        os.registerEvents(doc.getElementById('dockList'), {
            event: 'touchend',
            callback: function (el) {
              if(el.target.id === "dockList"){//we only want the elements inside
                return;
              }
              clearTimeout(holdTimer);
                if (!moving && !holding) {
                    if (el.target.id === 'app1') {
                        appDrawer.toggleDrawer('open');
                        //loadEvents(); //load and unload closer event;
                    } else {
                        openApp(el.target.title);
                    }
                }
                moving = false;
                holding = false;
                el.target.style['-webkit-transform'] = 'scale(1) translate(0,0)';
                startX = null;
            }
        });

        os.registerEvents(doc.getElementById('dockList'),{
            event: 'touchcancel',
            callback: function (el) {
              if(el.target.id === "dockList"){//we only want the elements inside
                return;
              }
              clearTimeout(holdTimer);
                if (!moving && !holding) {
                    if (el.target.id === 'app1') {
                        appDrawer.toggleDrawer('open');
                        //loadEvents(); //load and unload closer event;
                    } else {
                        openApp(el.target.title);
                    }
                }
                moving = false;
                holding = false;
                el.target.style['-webkit-transform'] = 'scale(1) translate(0,0)';
                startX = null;
            }
        });

        //onload.js
        // macDock.createSlider = function () {
        //     createSlider();
        // };
        //
        //orientation.js
        macDock.getSwitcher = function () {
            getSwitcher();
        };
        macDock.updateBadgesForDock = function () {
            updateBadgesForDock();
        };
        //helper.js os.js
        macDock.setupDock = function () {
            setupDock();
        };
        return macDock;
    }
    window.macDock = load_macDock();
}(window, document));
