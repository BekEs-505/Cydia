/*jslint
  node: true,
  sloppy: true,
  browser: true,
  todo: true
*/

/*global
  window,
  os,
  iconDrawer,
  appBundles,
  alert,
  translate,
  current,
  IS2W,
  IS2M,
  defaultmusicapp
*/

(function (window, doc) {

    var load_widgetContainer = function () {
        var widgetContainer = {
                isShowing: false
            },
            updateWeather = function () {
                var f,
                    iconLocation = 'src/images/weather/',
                    correctImage,
                    days = JSON.parse(FPI.weather.dayForecasts),
                    celsius = (FPI.weather.celsius) ? 'C' : 'F';

                doc.getElementById('icon').src = iconLocation + FPI.weather.conditionCode + '.png';
                doc.getElementById('lastupdate').innerHTML = FPI.weather.updateTimeString;
                
              //  doc.getElementById('temp').innerHTML = FPI.weather.temperature + "&deg;";

                for (f = 1; f < 5; f += 1) {
                    correctImage = (days[f].condition === 3200) ? iconLocation + FPI.weather.conditionCode + ".png" : iconLocation + days[f].condition + ".png";
                    doc.getElementById('day' + f + 'icon').src = correctImage;
                    doc.getElementById('day' + f + 'temphi').innerHTML = days[f].high + '&deg;' + celsius;
                    doc.getElementById('day' + f + 'templo').innerHTML = days[f].low + '&deg;' + celsius;
                    doc.getElementById('day' + f + 'day').innerHTML = translate[current].sday[days[f].dayOfWeek - 1];
                }
            },
            show = function () {
                doc.getElementById('widgetContainer').classList.toggle('showingWidgets');
            };

        widgetContainer.show = function () {
            widgetContainer.isShowing = true;
            show();
            //IS2W('updateWeather');
            //setTimeout(updateWeather, 100);
        };
        widgetContainer.hide = function () {
            doc.getElementById('widgetContainer').classList.toggle('showingWidgets');
            widgetContainer.isShowing = false;
        };

        return widgetContainer;
    };


    window.widgetContainer = load_widgetContainer();

}(window, document));


var musicController = {
    play: function () {
        //IS2M('togglePlayPause');
        playMusic();
        //musicController.check();
    },
    next: function () {
        nextTrack();
    },
    prev: function () {
        prevTrack();
    },
    open: function () {
        openApp(FPI.music.bundle);
    }
};

document.getElementById('controls').addEventListener(os.handlerType(), function (el) {
    document.getElementById(el.target.id).classList.toggle('press');
    setTimeout(function () {
        document.getElementById(el.target.id).classList.toggle('press');
    }, 300);
    musicController[el.target.id]();
});
document.getElementById('albumArt').addEventListener(os.handlerType(), function () {
    document.getElementById('albumArt').classList.toggle('large');
});
