/*jslint
  node: true,
  sloppy: true,
  browser: true,
  todo: true
*/

/*global
  appInfo,
  appDrawer,
  iconDrawer,
  os,
  findershowkeyboard
*/


(function (window) {
    function load_finder() {
        var macFinder = {},
            doc = document,
            finderInput = doc.getElementById('finderInput'),
            finderApps = doc.getElementById('finderApps'),
            finderContainer = doc.getElementById('finder'),
            //blobArray = [],
            fillFinder = function () {
                var array = FPI.apps.all,
                    i,
                    name,
                    bundle,
                    icon,
                    badge,
                    listItem,
                    mainDiv,
                    badgeHolder,
                    iconImage,
                    appLabel,
                    badgeSpan,
                    //blob,
                    fragment = doc.createDocumentFragment();

                for (i = 0; i < array.length; i += 1) {
                    name = array[i].name;
                    bundle = array[i].bundle;

                    icon = '/var/mobile/Library/FrontPageCache/' + bundle + '.png';

                    //check for cached images if not cached add to cache
                    // if (appDrawer.cache.hasOwnProperty(bundle)) {
                    //     icon = appDrawer.cache[bundle];
                    // } else {
                    //     icon = array[i].icon;
                    //     appDrawer.cache[bundle] = icon;
                    // }

                    //if icon image is valid show it
                    if (icon !== 'null') { // check if icon image is valid
                        badge = array[i].badge;
                        mainDiv = os.createDOM({
                            type: 'div',
                            className: 'iconHolder',
                            attribute: ['title', bundle]
                        });
                        listItem = os.createDOM({
                            type: 'li',
                            id: bundle,
                            attribute: ['title', bundle],
                            attribute2: ['tag', name]
                        });
                        //blob = os.toBlob(icon); //dude blob array is slow af
                        //blobArray.push(blob);
                        iconImage = os.createDOM({
                            type: 'img',
                            src: icon //URL.createObjectURL(blob)
                        });
                        appLabel = os.createDOM({
                            type: 'label',
                            innerHTML: name
                        });
                        badgeSpan = os.createDOM({
                            type: 'span',
                            className: 'finderBadges',
                            innerHTML: ((badge > 0) ? badge : '')
                        });
                        badgeHolder = os.createDOM({
                            type: 'a',
                            className: 'finderBadgesHolder',
                            appendChild: badgeSpan
                        });
                        mainDiv.appendChild(iconImage);
                        mainDiv.appendChild(appLabel);
                        mainDiv.appendChild(badgeHolder);
                        listItem.appendChild(mainDiv);
                    }
                    fragment.appendChild(listItem);
                }
                finderApps.appendChild(fragment);
            },
            //remove events from the input box and from apps
            removeEvents = function () {
                os.unregisterEvents(finderInput);
                os.unregisterEvents(finderApps);
            },
            // removeBlobs = function () {
            //     if (blobArray.length > 1) {
            //         var i;
            //         for (i = 0; i < blobArray.length; i += 1) {
            //             try {
            //                 URL.revokeObjectURL(blobArray[i]);
            //             } catch (err) {
            //                 os.message('105 finder.js Error', err);
            //             }
            //         }
            //     }
            // },
            //clear elements from finder
            clearFinder = function () {
                removeEvents(); //makes sense to remove events first
                //removeBlobs();
                while (finderApps.firstChild) {
                    finderApps.removeChild(finderApps.firstChild);
                }
            },
            //when user presses a key search the list
            searchFinder = function () {
                var filter, li, a, i;
                filter = finderInput.value.toUpperCase();
                li = finderApps.getElementsByTagName('li');
                for (i = 0; i < li.length; i += 1) {
                    a = li[i].getAttribute('tag');
                    if (a.toUpperCase().indexOf(filter) > -1) {
                        li[i].style.display = "";
                    } else {
                        li[i].style.display = "none";
                    }
                }
            },
            //toggle class to remove from view, clear input innerHTML, set height, remove keyboard,
            //clearFinder which removes all innerHTML and events
            closeFinder = function () {
                finderContainer.className = 'finder menuToggle';
                finderInput.innerHTML = '';
                finderContainer.style.height = '40px';
                finderInput.blur();
                clearFinder();
            },
            //add events here so can remove later
            addEvents = function () {
                os.registerEvents(finderInput, {
                    event: 'keyup',
                    callback: function () {
                        finderContainer.style.height = '100px';
                        searchFinder();
                    }
                });
                os.registerEvents(finderInput, {
                    event: 'blur',
                    callback: function () {
                        closeFinder();
                    }
                });
                os.registerEvents(finderApps, {
                    event: os.handlerType(),
                    callback: function (el) {
                        finderInput.blur();
                        openApp(os.checkApp(el.target.title));
                    }
                });
            },
            //initializes the finder, adds events, toggles it to animate, focus keyboard,
            //and get all apps
            showFinder = function () {
                //var startTime = new Date().getTime(), endTime;
                macTerminal.close();
                os.toggleClassList(doc, 'finder', 'menuToggle');
                fillFinder();
                addEvents();
                if (findershowkeyboard) {
                    finderInput.focus();
                }
                //endTime = new Date().getTime();
                //os.message('Finder.js showFinder()', "Time to execute: " + (endTime - startTime) + "ms");
                return true;

            };

        //add to object for global usage
        macFinder.showFinder = function () {
            showFinder();
        };
        macFinder.closeFinder = function () {
            closeFinder();
        };

        return macFinder;
    }

    window.macFinder = load_finder();
}(window));
