/*jslint
  node: true,
  sloppy: true,
  browser: true,
  todo: true
*/

/*global
  os,
  alert,
  iconDrawer,
  appDrawer
*/


(function () {
    function load_folderSetup() {
        var folderSetup = {},
            desktopIcons = document.getElementById('desktopIcons'),
            folderView = document.getElementById('folderView'),
            desktopIconsMoving = false,
            iconsScrolling = false,
            badge,
            name,
            icon,
            startX,
            mainDiv,
            folders,
            openFolder = function (folderName, recents) {
                var array, i, childDiv;
                os.clearDiv(folderView);
                if (recents) {
                    array = openedApps;
                } else {
                    array = folders[folderName];
                }
                for (i = 0; i < array.length; i += 1) {
                    if (String(array[i].displayName) !== 'Newsstand') {
                        //alert(array[i]); //here is where webclip could show
                        name = FPI.bundle[array[i]].name; //iconDrawer.getNameFromBundle(array[i]);
                        childDiv = os.createDOM({
                            type: 'div',
                            className: 'folderIcons',
                            attribute: ['title', array[i]],
                            attribute2: ['data-title', name]
                        });
                        if (appDrawer.cache.hasOwnProperty(array[i])) {
                            icon = appDrawer.cache[array[i]];
                        } else {
                            icon = '/var/mobile/Library/FrontPageCache/' + array[i] + '.png';
                            appDrawer.cache[array[i]] = icon;
                        }
                        badge = os.createDOM({
                            type: 'label',
                            className: 'folderBadges',
                            innerHTML: (FPI.bundle[array[i]].badge > 0) ? FPI.bundle[array[i]].badge : ''
                        });
                        childDiv.style.backgroundImage = 'url("' + icon + '")';
                        childDiv.appendChild(badge);
                        folderView.appendChild(childDiv);
                    }
                }
                document.getElementById('folderHolder').className = 'folderHolder';
                folderView.appendChild(os.createDOM({
                    type: 'div',
                    className: 'hiddenIcon'
                }));
            },
            loadEvents = function () {
                os.registerEvents(desktopIcons, {
                    event: 'touchstart',
                    callback: function () {
                        desktopIconsMoving = false;
                        startX = event.touches[0].pageX;
                    }
                });
                os.registerEvents(desktopIcons, {
                    event: 'touchmove',
                    callback: function (el) {
                        if (el.touches[0].pageX > Number(startX + 5) || el.touches[0].pageX < Number(startX - 5)) {
                            desktopIconsMoving = true;
                        }
                    }
                });
                os.registerEvents(desktopIcons, {
                    event: 'touchend',
                    callback: function (el) {
                        if (!desktopIconsMoving) {
                            openFolder(el.target.getAttribute('data-title'));
                        }
                        desktopIconsMoving = false;
                        startX = null;
                    }
                });
                os.registerEvents(folderView, {
                    event: 'touchend',
                    callback: function (el) {
                        if (el.target.title && !iconsScrolling) {
                            openApp(el.target.title);
                            os.toggleClassList(document, 'folderHolder', 'menuToggle');
                            os.toggleClassList(document, 'desktopIcons', 'menuToggle');
                            document.getElementById('invisibleTapper').style.opacity = 1;
                        }
                        iconsScrolling = false;
                    }
                });
                os.registerEvents(folderView, {
                    event: 'touchstart',
                    callback: function () {
                        iconsScrolling = false;
                    }
                });
                os.registerEvents(folderView, {
                    event: 'touchmove',
                    callback: function () {
                        iconsScrolling = true;
                    }
                });

            },
            getFolders = function () {
                var key;
                folders = os.getFolders();
                os.clearDiv(folderView);
                os.clearDiv(desktopIcons);

                for (key in folders) {

                    if (folders.hasOwnProperty(key)) {
                        mainDiv = os.createDOM({
                            type: 'div',
                            className: 'folderIcon',
                            attribute2: ['data-title', key]
                        });
                        desktopIcons.appendChild(mainDiv);
                    }

                } /*endfor*/
                loadEvents();
            };
        //getFolders();

        folderSetup.getFolders = function () {
            getFolders();
        };
        folderSetup.openFolder = function (name, recents) {
            openFolder(name, recents);
        };

        return folderSetup;
    }
    window.folderSetup = load_folderSetup();
}());
