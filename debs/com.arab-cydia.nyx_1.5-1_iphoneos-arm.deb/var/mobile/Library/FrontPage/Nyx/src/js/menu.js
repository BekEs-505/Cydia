/*jslint
  node: true,
  sloppy: true,
  browser: true,
  todo: true
*/

/*global
  os,
  macFinder,
  iconDrawer,
  appBundles,
  macTerminal,
  confirm,
  IS2S,
  notification,
  autohidedock,
  openApp,
  folderSetup,
  isUninstall,
  appDrawer,
  sleep,
  FileReader
*/

//os.include('src/js/finder.js');
(function (window, doc) {
    function load_menu() {
        var macMenu = {},
            invisibleTimer = null,
            handleInvisibleTap = function () {
                var f;
                if (os.detectDoubleTap()) {
                    macFinder.showFinder();
                } else {
                    f = doc.getElementById('finder').className;
                    if (f === 'finder') {
                        macFinder.closeFinder();
                    }
                }

                os.closeAllMenusBesides('finder');

                if (autohidedock) {
                    document.getElementById('dock').className = 'dockshow';
                }

            },
            respring = function () {
                respring();
            },
            handleMenuTouch = function (title) {
                switch (title) {
                case 'about':
                    doc.getElementById('aboutOS').classList.toggle('menuToggle');
                    break;
                case 'system':
                    openApp(appBundles.settings);
                    break;
                case 'appstore':
                    openApp(appBundles.appstore);
                    break;
                case 'cydia':
                    openApp(appBundles.cydia);
                    break;
                case 'recent':
                    folderSetup.openFolder(null, true);
                    break;
                case 'exit':
                    os.popup('Respring: Are you sure you want to do this?', this.respring, "Yes", "No");
                    break;
                case 'quit':
                    iconDrawer.openSwitcher();
                    break;
                case 'helpInfo':
                    helpInfo();
                    //iconDrawer.sleep();
                    break;
                case 'restart':
                    location.reload();
                    break;
                case 'respring':
                    os.popup('RESPRING: You are about to respring the device. Are you sure you want to do this?', iconDrawer.respring, "Yes", "No");
                    break;
                case 'terminal':
                    macTerminal.open();
                    break;
                case 'uninstall':
                    isUninstall = true;
                    appDrawer.allApps();
                    appDrawer.toggleDrawer('open');
                    break;
                }
                doc.getElementById('mainMenu').classList.toggle('menuToggle');
                //doc.getElementById('appleIcon').classList.toggle('appleIconColor');
            };

        os.registerEvents(doc.getElementById('appleIcon'), {
            event: os.handlerType(),
            callback: function () {
                os.toggleClassList(document, 'mainMenu', 'menuToggle');
                macTerminal.close();
                doc.getElementById('aboutOS').className = "menuToggle";
                //  os.toggleClassList(document, 'appleIcon', 'appleIconColor');
                os.closeAllMenusBesides('mainMenu');
            }
        });
        os.registerEvents(doc.getElementById('invisibleTapper'), {
            event: 'touchstart',
            callback: function (el) {
                if (el.target === doc.getElementById('invisibleTapper')) {
                    handleInvisibleTap();
                    invisibleTimer = setTimeout(function () {
                        os.popup('Add icon to desktop?', appDrawer.toggleAppsForDesktop, "Yes", "No", true);
                        clearTimeout(invisibleTimer);
                    }, 2000);
                }
            }
        });
        os.registerEvents(doc.getElementById('invisibleTapper'), {
            event: 'touchend',
            callback: function () {
                clearTimeout(invisibleTimer);
            }
        });

        // well would be nice to have a user select an image for the about page.
        // I forgot iWidget doesn't support inputs
        doc.getElementById('bgInput').addEventListener('change', function (e) {
            var tw = e.target.files,
                rd = new FileReader();

            rd.onload = (function () {
                return function (e) {
                    localStorage.newImage = e.target.result;
                    doc.getElementById('avatar').style.backgroundImage = 'url("' + localStorage.newImage + '")';
                    tw = null;
                    rd = null;
                };
            }(tw[0]));
            rd.readAsDataURL(tw[0]);
        });

        os.registerEvents(doc.getElementById('mainMenu'), {
            event: os.handlerType(),
            callback: function (el) {
                if (el.target.title && el.target.nodeName === 'LI') {
                    handleMenuTouch(el.target.title);
                }
            }
        });

        os.registerEvents(doc.getElementById('aboutClose'), {
            event: os.handlerType(),
            callback: function () {
                os.toggleClassList(document, 'aboutOS', 'menuToggle');
            }
        });

        return macMenu;
    }

    window.macMenu = load_menu(); //Will I need something from here?
}(window, document));
