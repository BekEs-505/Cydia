/*jslint
  node: true,
  sloppy: true,
  browser: true,
  todo: true
*/

/*global
  window,
  os,
  iconDrawer,
  appBundles,
  alert
*/


/*
macTerminal

The point of the code below is to encapsulate all functions used for the terminal.
There is a macTerminal pushed to window.macTerminal this contains functions needed
for menus etc.. to open and close macTerminal use macTerminal.open() or macTerminal.close()

Events will load and unload theirselves when macTerminal.open() or macTerminal.close() are called.

** Setup Events **
os.registerEvents(doc.get('something'), {
    event: 'click',
    callback: function (event) {
        //onTerminalChange(event);
    }
});

** Unload Events **
os.unregisterEvents(doc.get('something'));

statusbar.dontcollapse() //stops small section from hiding
statusbar.autocollapse() //statusbar will hide a small section
statusbar.hidebattery();
statusbar.showbattery();

//variables
bounce = false //disable dock bouncing
autohidedock = false;

** Terminal Commands **
help = shows help info
list = lists globals and methods
close = close terminal
respring = respring device

*/


(function (window) {
    function load_terminal() {
        var macTerminal = {},
            doc = document,
            term = doc.getElementById('terminalApp'),
            termText = doc.getElementById('terminalText'),
            termOutput = doc.getElementById('terminalOutput'),
            termClose = doc.getElementById('terminalClose'),
            termLast,
            appendOutput = function (value, term_class) {
                var element = doc.createElement("div"),
                    div = doc.createElement("div"),
                    span = doc.createElement("div");
                span.innerHTML = value;
                span.className = 'terminalOutputDiv';
                element.className = term_class;
                div.appendChild(span);
                element.appendChild(div);
                termOutput.appendChild(element);
            },
            clearOutput = function () {
                termOutput.innerHTML = "";
            },
            unloadEvents = function () {
                os.unregisterEvents(termText);
                os.unregisterEvents(term);
                os.unregisterEvents(termClose);
            },
            close = function () {
                var d = document,
                    f = d.getElementById('terminal').className;
                if (f === 'terminal') {
                    os.toggleClassList(d, 'terminal', 'menuToggle');
                    d.getElementById('terminalText').blur();
                }
                unloadEvents();
            },
            handleTap = function () {
                if (os.detectDoubleTap()) {
                    if (termLast.length > 0) {
                        termText.value = termLast;
                    }
                }
            },
            handleOutput = function (value) {
                termLast = value;
                var output;
                if (value === "clear") {
                    clearOutput();
                } else if (value === 'help') {
                    doc.getElementById('help').style.display = 'block';
                    termText.blur();
                } else if (value === 'list') {
                    appendOutput('Globals variables: <br></br>' +
                        'findershowkeyboard = true <br> ' +
                        'app2-app5 = appBundles[\"notes\"] <br>' +
                        'popuptime = 3000 </br>' +
                        'showpopup = true </br>' +
                        'bounce = false </br>' +
                        'appBundles["mail"] (bundle id)' +
                        '</br></br>' +
                        'Functions: </br></br>' +
                        'os.showPopup("Test", "Testing popup");</br>' +
                        'os.open("mail");</br>' +
                        'os.dock(2, "mail");' +
                        '</br></br>' +
                        'Commands: </br></br>' +
                        'clear - clears screen </br>' +
                        'respring - resprings device </br></br>' +
                        'statusbar.methods() - do stuff to statusbar</br>' +
                        'os.methods() - do stuff to the os </br>' +
                        '', 'evaluated_input');
                } else if (value === 'respring') {
                    respring();
                } else if (value === 'close') {
                    close();
                } else {
                    try {
                        output = eval(value);
                    } catch (err) {
                        appendOutput(err, 'term_error');
                    }
                    appendOutput("iOS> " + value, 'copied_input');
                    appendOutput(output, 'evaluated_input');
                }
                term.scrollTop = term.scrollHeight;
            },
            terminalHandleEnter = function () {
                handleOutput(termText.value);
                termText.value = "";
            },
            onTerminalChange = function (event) {
                if (window.event.keyCode === 13) {
                    terminalHandleEnter();
                    event.preventDefault();
                }
                return true;
            },
            loadEvents = function () {
                os.registerEvents(termText, {
                    event: 'keypress',
                    callback: function (event) {
                        onTerminalChange(event);
                    }
                });
                os.registerEvents(term, {
                    event: 'click',
                    callback: function () {
                        termText.focus();
                    }
                });
                os.registerEvents(termClose, {
                    event: os.handlerType(),
                    callback: function () {
                        close();
                    }
                });
                os.registerEvents(termText, {
                    event: os.handlerType(),
                    callback: function () {
                        handleTap();
                    }
                });
            },
            open = function () {
                doc.getElementById('terminal').classList.toggle('menuToggle');
                loadEvents();
            };

        //add terminalClose to object
        // I added isntInTerminal and isInTerminal so I can enable/disable copy/paste.
        // This is done in FrontPage. By default copy/paste is disabled.

        macTerminal.close = function () {
            close();
            window.location = 'frontpage:isntInTerminal';
        };
        macTerminal.open = function () {
            open();
            window.location = 'frontpage:isInTerminal';
        };

        return macTerminal;
    }
    //make object available globally
    window.macTerminal = load_terminal();
}(window));
