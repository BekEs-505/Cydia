/*jslint
  node: true,
  sloppy: true,
  browser: true,
  todo: true
*/

/*global
  nslog,
  os,
  console,
  iconDrawer,
  appBundles,
  folderSetup,
  macDock,
  macFinder,
  notification,
  autohidedock,
  widgetContainer,
  atob,
  ArrayBuffer,
  Uint8Array,
  Blob,
  FPI,
  showpopup,
  popuptime
*/



function addStyleString(str) {
    var node = document.createElement('style');
    node.innerHTML = str;
    document.body.appendChild(node);
}

//setup global variables for users to change via terminalCache
window.findershowkeyboard = true;
window.showpopup = true;
window.popuptime = 6000;

window.bouncing = localStorage.bouncing || true;

window.autohidedock = false;
window.landscape = localStorage.landscape || true;

window.disablewall = localStorage.disablewall || false;


var os = {}; //object to throw methods into instead of having them global

//for terminal
os.open = function (name) {
    iconDrawer.openApp(appBundles[name]);
    return true;
};

os.bouncing = function (state) {
    localStorage.bouncing = state;
    window.bouncing = state;
    return "Bouncing has been saved";
};

os.disablestartanimations = function(){
    localStorage.disablestartanimations = true;
    return "Start animations disabled";
}
os.enablestartanimations = function(){
    localStorage.removeItem('disablestartanimations');
    return "Start animations restored";
}
os.badgecolor = function (color, fromStorage) {
    var css = ".dockBadge,.finderBadges,.drawerBadges,.homescreenBadges, #appicons ul li:after{background-color:" + color + "}",
        style = document.createElement('style');
    style.type = 'text/css';
    style.appendChild(document.createTextNode(css));
    document.getElementsByTagName('head')[0].appendChild(style);
    localStorage.badgeColor = color;
    if (!fromStorage) {
        os.showPopup('Terminal', "Badges changed to " + color);
    }
    return true;
};
os.methods = function () {
    var res = [],
        m;
    for (m in os) {
        if (typeof os[m] === "function") {
            res.push(m + '<br>');
        }
    }
    return res;
};
os.disablewall = function () {
    document.getElementById('fakeBlur').style.backgroundImage = 'url("")';
    document.getElementById('iWidget').style.backgroundImage = 'url("")';
    //os.showPopup('Terminal', "Disabled Wallpaper os.enablewall() to enable it again.");
    localStorage.disablewall = true;
    return true;
};
os.enablewall = function () {
    document.getElementById('fakeBlur').style.backgroundImage = 'url("src/images/minimac.png")';
    document.getElementById('iWidget').style.backgroundImage = 'url("src/images/mac.png")';
    //os.showPopup('Terminal', "Enabled Wallpaper os.disablewall() to disable it.");
    localStorage.disablewall = false;
    //iconDrawer.setDarkBG();
    return true;
};
os.floatingstatusbar = function () {
    os.getEl('statusbar').style.cssText = "margin-top: 4px; width: 98%;border-radius:5px;";
    os.getEl('wifiMenu').style.cssText = "top:18px;";
    addStyleString('.mainMenu{top:18px;left:12px;}.notificationMenu {top:34px;}.batteryMenu,.calendarMenu{top:18px;}');
    localStorage.floatingstatusbar = true;
    return "Floating statusbar set";
};
os.disablefloatingstatusbar = function () {
    os.getEl('statusbar').style.cssText = "margin-top: 0px; width: 100%;border-radius:0px;";
    os.getEl('wifiMenu').style.cssText = "top:14px;";
    addStyleString('.mainMenu{top:14px;left:5px;}.batteryMenu, .calendarMenu{top:14px;}.notificationMenu {top:30px;}');
    localStorage.removeItem('floatingstatusbar');
    return "Floating statusbar removed";
};
os.darkmode = function () {
    addStyleString('.folderHolder{background-color:rgba(0,0,0,0.8);}#desktopIcons{background-color:rgba(0,0,0,0.6);}#aboutOS{background-color: rgba(0, 0, 0, 0.8);color: white;}.container{color: rgba(255, 255, 255, 0.4);}.calendar-day {border-left: solid 1px rgba(255, 255, 255, 0.1);}.today {color:white;}.calendarMenu {background-color: rgba(0, 0, 0, 0.8);}.datewidget {color:white;}#dock {background-color: rgba(0, 0, 0, 0.6);}.dockBadge {background-color: red;}.finder {background-color: rgba(0, 0, 0, 0.6);}#finderInput {color:white;}#finderApps label {color:white;}.finderBadges{background-color:red;}.searchIcon{color:white;}.appContainer {background-color: rgba(0, 0, 0, 0.6); color:white;}#iconContainer label {color:white;text-shadow: 0px 1px 2px rgba(0, 0, 0, 0);}.drawerBadges {background-color:red;color:white;}.homescreenBadges {color:white;}.folderIcon::after {color:white; text-shadow: 0px 1px 2px rgba(0, 0, 0, 0);}.folderIcons::after {color:white;}.folderBadges {background-color:white;}.mainMenu {background-color: rgba(0, 0, 0, 0.8);}.mainMenu li {color:white;}.mainMenu li:nth-child(1):after{background-color: rgba(255, 255, 255, 0.2);}.mainMenu li:nth-child(4):after {background-color: rgba(255, 255, 255, 0.2);}.mainMenu li:nth-child(5):after {background-color: rgba(255, 255, 255, 0.2);}.mainMenu li:nth-child(7):after {background-color: rgba(255, 255, 255, 0.2);}.notificationMenu {background-color: rgba(0, 0, 0, 0.8);}.notificationMenu h2 {color:white;}#appicons ul li:after {background-color:red;}#appicons ul li:before {color:white;}#infoContainer li {color:white;background-color: rgba(0, 0, 0, 0.2);}#infoContainer li:before {color:white;} #infoPopup {background-color: rgba(0, 0, 0, 0.9);color:white;}#infoClose:after {color:white;}#infoClose:before {background-color:white;}#notificationPopup {background-color: rgba(0, 0, 0, 0.8);}#notificationTitle {color:white;}#notificationText {color:white;}#systemPopup {background-color: rgba(0, 0, 0, 0.9);color:white;}#systemYes {color:white;background-color: rgba(0, 0, 0, 0.1);}#systemYes:: after {color:white;}#systemNo {color:white; background-color:rgba(0,0,0,0.1);}#systemNo:: after {color:white;}#systemMessage {color:white;}.statusbar {background-color: rgba(0, 0, 0, 0.8);color:white;}#battery {border: 1px solid white;}#battery:after {background-color:white;}#batteryinsides {background-color:white;}.terminal {background-color: black;}.terminalClose:after {color:white;}.terminalApp {color:white;}.terminalText {background-color:black;color:white;}.weatherHolder {background-color: rgba(0, 0, 0, 0.8);color:white;}.musicHolder {background-color: rgba(0, 0, 0, 0.8);color:white;}.forecast{color:white;}.playButton,.forwardButton, .backButton{background-color:black;color:white;border: 2px solid black;}.artist, .title, .volumeUp, .volumeDown{color:white;}.wifiMenu{background-color:rgba(0,0,0,0.8);}.wifiMenu li{color:white;}.wifiMenu li:nth-child(1):after {background-color:rgba(255,255,255,0.2)}#wifiButton{background-color:rgba(255,255,255,0.2);}.batteryMenu{background-color:rgba(0,0,0,0.8)}.batteryMenu li{color:white;}.batteryMenu li:nth-child(1):after {background-color: rgba(255,255,255,0.2);}.z-slide-indicator .z-slide-dot {background-color:rgba(255,255,255,0.2);}.z-slide-indicator .z-slide-dot.active {background-color: rgba(255, 255, 255, 0.9);}');
    addStyleString('#batterycharging, .notificationIcon, #wifi, .logo, .weatherIconImage{-webkit-filter: invert(0%);}');
    localStorage.removeItem('lightmode');
    return "Dark mode enabled";
};
os.lightmode = function () {
    addStyleString('.folderHolder{background-color:rgba(255,255,255,0.6);}#desktopIcons{background-color:rgba(255,255,255,0.6);}#aboutOS{background-color: rgba(255, 255, 255, 0.8);color: black;}.container{color: rgba(0, 0, 0, 0.4);}.calendar-day {border-left: solid 1px rgba(0, 0, 0, 0.1);}.today {color:black;}.calendarMenu {background-color: rgba(255, 255, 255, 0.8);}.datewidget {color:white;}#dock {background-color: rgba(255, 255, 255, 0.6);}.dockBadge {background-color: black;}.finder {background-color: rgba(255, 255, 255, 0.6);}#finderInput {color:black;}#finderApps label {color:black;}.finderBadges{background-color:black;}.searchIcon{color:black;}.appContainer {background-color: rgba(255, 255, 255, 0.6); color:black;}#iconContainer label {color:black;text-shadow: 0px 1px 2px rgba(0, 0, 0, 0);}.drawerBadges {background-color:black;color:white;}.homescreenBadges {color:white;}.folderIcon::after {color:black; text-shadow: 0px 1px 2px rgba(0, 0, 0, 0);}.folderIcons::after {color:black;}.folderBadges {background-color:black;}.mainMenu {background-color: rgba(255, 255, 255, 0.8);}.mainMenu li {color:black;}.mainMenu li:nth-child(1):after{background-color: rgba(0, 0, 0, 0.2);}.mainMenu li:nth-child(4):after {background-color: rgba(0, 0, 0, 0.2);}.mainMenu li:nth-child(5):after {background-color: rgba(0, 0, 0, 0.2);}.mainMenu li:nth-child(7):after {background-color: rgba(0, 0, 0, 0.2);}.notificationMenu {background-color: rgba(255, 255, 255, 0.8);}.notificationMenu h2 {color:black;}#appicons ul li:after {background-color:black;}#appicons ul li:before {color:black;}#infoContainer li {color:black;background-color: rgba(0, 0, 0, 0.2);}#infoContainer li:before {color:black;} #infoPopup {background-color: rgba(255, 255, 255, 0.9);color:black;}#infoClose:after {color:black;}#infoClose:before {background-color:black;}#notificationPopup {background-color: rgba(255, 255, 255, 0.8);}#notificationTitle {color:black;}#notificationText {color:black;}#systemPopup {background-color: rgba(255, 255, 255, 0.9);color:black;}#systemYes {color:black;background-color: rgba(0, 0, 0, 0.1);}#systemYes:: after {color:black;}#systemNo {color:black; background-color:rgba(0,0,0,0.1);}#systemNo:: after {color:black;}#systemMessage {color:black;}.statusbar {background-color: rgba(255, 255, 255, 0.8);color:black;}#battery {border: 1px solid black;}#battery:after {background-color:black;}#batteryinsides {background-color:black;}.terminal {background-color: white;}.terminalClose:after {color:black;}.terminalApp {color:black;}.terminalText {background-color:white;color:black;}.weatherHolder {background-color: rgba(255, 255, 255, 0.8);color:black;}.musicHolder {background-color: rgba(255, 255, 255, 0.8);color:black;}.forecast{color:black;}.playButton,.forwardButton, .backButton{background-color:black;color:white;border: 2px solid white;}.artist, .title, .volumeUp, .volumeDown{color:black;}.wifiMenu{background-color:rgba(255,255,255,0.8);}.wifiMenu li{color:black;}.wifiMenu li:nth-child(1):after {background-color:rgba(0,0,0,0.1)}#wifiButton{background-color:rgba(0,0,0,0.1);}.batteryMenu{background-color:rgba(255,255,255,0.8)}.batteryMenu li{color:black;}.batteryMenu li:nth-child(1):after {background-color: rgba(0,0,0,0.2);}.z-slide-indicator .z-slide-dot {background-color:rgba(255,255,255,0.2);}.z-slide-indicator .z-slide-dot.active {background-color: rgba(0, 0, 0, 0.9);}');
    addStyleString('#batterycharging, .notificationIcon, #wifi, .logo, .weatherIconImage{-webkit-filter: invert(100%);}');
    localStorage.lightmode = true;
    return "Light mode enabled";
};
os.disablefolderbg = function(){
    addStyleString('#desktopIcons{background-color: rgba(0, 0, 0, 0);-webkit-backdrop-filter: blur(0px);}');
    localStorage.folderbg = true;
    return "Folder background hidden.";
};
os.enablefolderbg = function(){
    addStyleString('#desktopIcons{background-color: rgba(0, 0, 0, 0.8);-webkit-backdrop-filter: blur(10px);}');
    localStorage.removeItem('folderbg');
    return "Folder background will now show.";
};
os.disablefloatingfolder = function(){
    addStyleString('#desktopIcons { right: 0px;border-radius:0px;border-top-left-radius: 5px;border-bottom-left-radius: 5px;}');
    localStorage.removeItem('floatingfolder');
    return "Floating folder disabled";
};
os.floatingfolder = function(){
    addStyleString('#desktopIcons {right: 5px;border-radius : 5px;}');
    localStorage.floatingfolder = true;
    return "Folder menu will now sit off of the edge.";
};

// os.movesb = function () {
//     iconDrawer.enablePaging();
//     return "Paging is enabled";
// };
// os.locksb = function () {
//     iconDrawer.disablePaging();
//     return "Paging is disabled";
// };

os.getfolders = function () {
    folderSetup.getFolders();
    return "Checked folders";
};


os.dockiconsize = function (size) {
    addStyleString('ul.osxdock li a img {width: ' + size + 'px;}');
    localStorage.dockiconsize = size;
    return "Dock icon size is now " + size + "px";
};

os.resetdockiconsize = function () {
    addStyleString('ul.osxdock li a img {width: 40px;}');
    localStorage.removeItem('dockiconsize');
    return "Reset dock icon size";
};

os.hidedivider = function () {
    addStyleString('.osxdock li:nth-child(14):before {display:none;}.osxdock li:nth-child(10):before{display:none;}');
    localStorage.dockdivider = true;
    return "Removed divider";
};

os.showdivider = function () {
    addStyleString('.osxdock li:nth-child(14):before {display:block;}.osxdock li:nth-child(10):before{display:block;}');
    localStorage.removeItem('dockdivider');
    return "Show divider";
};
os.dateright = function(){
  addStyleString('.datewidget{right:0;}');
  localStorage.dateright = true;
  return "Date widget moved to the right may need a respring.";
}
os.dateleft = function(){
  addStyleString('.datewidget{left:0;}');
  localStorage.removeItem('dateright');
  return "Date widget moved to the left may need a respring.";
}
os.dock = function (position, name) {
    window["app" + position] = appBundles[name];
    macDock.setupDock();
    localStorage.setItem("app" + position, appBundles[name]);
    os.showPopup('Terminal', "Dock Icon changed. To reset to defaults use </br> os.dockDefaults()");
    return "Dock icon #" + position + " changed to " + name;
};

os.widedock = function () {
    os.getEl('dock').style.cssText = "width:100%; border-radius:0;";
    localStorage.widedock = true;
    return "Wide dock enabled";
};

os.disablewidedock = function () {
    os.getEl('dock').style.cssText = "width:90%; border-radius:4";
    localStorage.removeItem('widedock');
    return "Wide dock disabled";
};

os.moredockicons = function () {
    localStorage.moredockicons = true;
    addStyleString('ul.osxdock li a img {width: 30px;height:30px;} #dock{height:50px;}.osxdock li:nth-child(14):before {margin-left: -23px;margin-top: 4px;}');
    addStyleString('@media only screen and (min-device-width: 768px) and (max-device-width: 1024px){ .osxdock li:nth-child(14):before {margin-left: -25px;} }');
    return "Dock will now have more icons, but smaller:)";
};
os.lessdockicons = function () {
    localStorage.removeItem('moredockicons');
    addStyleString('ul.osxdock li a img {width: 40px;} #dock{height:65px;} .osxdock li:nth-child(14):before {margin-left: -30px; margin-top:8px;}');
    //addStyleString('@media only screen and (min-device-width: 768px) and (max-device-width: 1024px){ .osxdock li:nth-child(14):before {margin-left: -25px;} }');
    return "Dock will now have less icons, but bigger:)";
};
os.floatingdock = function () {
    localStorage.floatingdock = true;
    addStyleString('.dockshow{ bottom: 10px;} #dock{border-radius: 10px;}');
    return 'Dock will now float off the bottom';
};
os.disablefloatingdock = function () {
    localStorage.removeItem('floatingdock');
    addStyleString('.dockshow{ bottom: -4px;} #dock{border-radius: 4px;}');
    return 'Dock will now stick to the bottom';
};

os.setIcon = function (divid, bundle) {
    window[divid] = bundle;

    macDock.setupDock();
    localStorage.setItem(divid, bundle);
    os.showPopup('Terminal', "Dock Icon changed. To reset to defaults use </br> os.dockDefaults() in Terminal.");
    return "Dock icon " + divid + " changed to " + bundle;
};

// <div id="systemPopup">
//     <div id="systemClose"></div>
//     <div id="systemMessage">Are you sure you want to respring?</div>
//     <div class="systemOptions">
//         <div id="systemYes" title="Yes"></div>
//         <div id="systemNo" title="No"></div>
//     </div>
// </div>

os.popup = function (message, funcYes, btnTxtYes, btnTxtNo, closeALL) {
    var systemPopup = os.createDOM({
            type: 'div',
            id: 'systemPopup'
        }),
        systemMessage = os.createDOM({
            type: 'div',
            id: 'systemMessage',
            innerHTML: message
        }),
        systemOptions = os.createDOM({
            type: 'div',
            className: 'systemOptions'
        }),
        systemYes = os.createDOM({
            type: 'div',
            id: 'systemYes',
            innerHTML: btnTxtYes,
            attribute: ['title', btnTxtYes]
        }),
        systemNo = os.createDOM({
            type: 'div',
            id: 'systemNo',
            innerHTML: btnTxtNo,
            attribute: ['title', btnTxtNo]
        });

    systemPopup.appendChild(systemMessage);
    systemOptions.appendChild(systemYes);
    systemOptions.appendChild(systemNo);
    systemPopup.appendChild(systemOptions);
    document.getElementById('iWidget').appendChild(systemPopup);

    (function () {
        var unloadEvents = function () {
                os.unregisterEvents(systemNo);
                os.unregisterEvents(systemYes);
            },
            loadEvents = function () {
                os.registerEvents(systemYes, {
                    event: os.handlerType(),
                    callback: function () {
                        funcYes();
                        if (closeALL) {
                            systemPopup.remove();
                        }
                    }
                });
                os.registerEvents(systemNo, {
                    event: os.handlerType(),
                    callback: function () {
                        unloadEvents();
                        systemPopup.remove();
                    }
                });

            };
        loadEvents();
    }());
};


os.dockDefaults = function () {
    var i;
    for (i = 1; i < 16; i += 1) {
        localStorage.removeItem("app" + i);
    }
    localStorage.removeItem('widedock');
    localStorage.removeItem('dockLayout');
    localStorage.removeItem('dockheight');
    localStorage.removeItem('dockiconsize');
    localStorage.removeItem('dockwidth');
    localStorage.removeItem('dockbgcolor');
    localStorage.removeItem('moredockicons');
    location.reload();
};

os.clearStorage = function () {
    localStorage.clear();
    location.reload();
};

os.set = function (div, style, value) {
    document.getElementById(div).style[style] = value;
    return "Set " + div + " style";
};

os.hide = function (div) {
    os.set(div, 'display', 'none');
    return div + " hidden os.show() to show it.";
};
os.show = function (div) {
    os.set(div, 'display', 'block');
    return div + " is visible";
};

os.dockwidth = function (number) {
    document.getElementById('dock').style.width = number + "%";
    localStorage.dockwidth = number;
    return "Dock width set to " + number + "% of the screen width";
};

os.resetdockwidth = function () {
    document.getElementById('dock').style.width = "90%";
    localStorage.removeItem('dockwidth');
    return "Dock width reset";
};

os.dockheight = function (number) {
    document.getElementById('dock').style.height = number + "px";
    localStorage.dockheight = number;
    return "Dock height set to " + number + "px tall";
};

os.resetdockheight = function () {
    document.getElementById('dock').style.height = "65px";
    localStorage.removeItem('dockheight');
    return "Dock height reset";
};

os.dockcolor = function (color) {
    document.getElementById('dock').style.backgroundColor = color;
    localStorage.dockbgcolor = color;
    return "Dock color changed. Use os.resetdockcolor() to reset";
};

os.resetdockcolor = function () {
    localStorage.removeItem('dockbgcolor');
    document.getElementById('dock').style.backgroundColor = "rgba(0, 0, 0, 0.6)";
    return "Dock color set to default";
};

//toggles items className
os.toggleClassList = function (docRef, divId, className) {
    docRef.getElementById(divId).classList.toggle(className);
};

//used to include other javascript files in the javascript file
os.include = function (file) {
    var script = document.createElement('script');
    script.src = file;
    script.type = 'text/javascript';
    document.getElementsByTagName('head').item(0).appendChild(script);
};

os.closeAllMenusBesides = function (besides) {

    var doc = document,
        f,
        menu,
        batt,
        fV,
        cal,
        info,
        n,
        sW;

    if (besides !== 'finder') {
        f = doc.getElementById('finder').className;
        if (f === 'finder') {
            macFinder.closeFinder();
        }
    }

    if (besides !== 'mainMenu') {
        menu = doc.getElementById('mainMenu');
        if (menu.className !== 'mainMenu menuToggle') {
            os.toggleClassList(doc, 'mainMenu', 'menuToggle');
        }
    }

    if (besides !== 'wifiMenu') {
        if (doc.getElementById('wifiMenu').className !== 'wifiMenu menuToggle') {
            os.toggleClassList(doc, 'wifiMenu', 'menuToggle');
        }

    }

    if (besides !== 'batteryMenu') {
        batt = doc.getElementById('batteryMenu').className;
        if (batt === 'batteryMenu') {
            os.toggleClassList(doc, 'batteryMenu', 'menuToggle');
        }
    }

    if (besides !== 'folderHolder') {
        fV = doc.getElementById('folderHolder').className;
        if (fV === 'folderHolder') {
            os.toggleClassList(doc, 'folderHolder', 'menuToggle');
        }
    }

    if (besides !== 'calendarMenu') {
        cal = doc.getElementById('calendarMenu').className;
        if (cal === 'calendarMenu') {
            os.toggleClassList(doc, 'calendarMenu', 'menuToggle');
        }
    }
    if (besides !== 'notificationInfoPopup') {
        info = doc.getElementById('infoPopup').className;
        if (info === 'openPopup') {
            notification.closeInfoPopup();
        }
    }

    if (besides !== 'notificationMenu') {
        n = document.getElementById('notificationMenu').className;
        if (n === "notificationMenu notificationShow") {
            os.toggleClassList(document, 'notificationMenu', 'notificationShow');
            doc.getElementById('dock').className = 'dockshow';
            autohidedock = false;
            setTimeout(notification.hide, 100);
        }
    }

    if (besides !== 'widgetContainer') {
        sW = doc.getElementById('widgetContainer').className;
        if (sW === 'showingWidgets') {
            doc.getElementById('widgetContainer').classList.toggle('showingWidgets');
            widgetContainer.isShowing = false;
        }
    }

    if (document.getElementById('desktopIcons').className !== 'menuToggle') {
        os.toggleClassList(document, 'desktopIcons', 'menuToggle');
    }

    doc.getElementById('invisibleTapper').style.opacity = 1;

};

//messaging system to put to console.log or nslog for testing
os.message = function (string, val, alert) {
    try {
        console.log("OSMessage " + string + " " + val);
        //nslog("OSMessage " + string + " " + val);
        if (alert) {
            alert("OSMessage " + string + " " + val);
        }
    } catch (ignore) {
        //ignore
    }
};

os.notificationBundles = [];
os.clearDiv = function (divID) {
    while (divID.firstChild) {
        divID.removeChild(divID.firstChild);
    }
};

os.getInner = function (div) {
    return document.getElementById(div).innerHTML;
};

os.getEl = function (el) {
    return document.getElementById(el);
};

/*
create dom elements

var mainDiv = os.createDOM({
    type: 'div',
    id: 'newDiv',
    className: 'iconHolder',
    innerHTML: 'example',
    src: 'myimage.jpg',
    attribute: ['title', bundle]
    attribute2: ['title', bundle],

});

*/

os.dockmoving = false;

os.toBlob = function (dataURI, callback) {
    // convert base64 to raw binary data held in a string
    // doesn't handle URLEncoded DataURIs - see SO answer #6850276 for code that does this
    var byteString = atob(dataURI.split(',')[1]),

        // separate out the mime component
        //  mimeString = dataURI.split(',')[0].split(':')[1].split(';')[0],

        // write the bytes of the string to an ArrayBuffer
        ab = new ArrayBuffer(byteString.length),
        ia = new Uint8Array(ab),
        i,
        bb;

    for (i = 0; i < byteString.length; i += 1) {
        ia[i] = byteString.charCodeAt(i);
    }

    // write the ArrayBuffer to a blob, and you're done
    bb = new Blob([ab]);
    return bb;
};

os.createDOM = function (params) {
    var d = document.createElement(params.type);
    if (params.className) {
        d.setAttribute('class', params.className);
    }
    if (params.id) {
        d.id = params.id;
    }
    if (params.innerHTML) {
        d.innerHTML = params.innerHTML;
    }
    if (params.attribute) {
        d.setAttribute(params.attribute[0], params.attribute[1]);
    }
    if (params.attribute2) {
        d.setAttribute(params.attribute2[0], params.attribute2[1]);
    }
    if (params.attribute3) {
        d.setAttribute(params.attribute3[0], params.attribute3[1]);
    }
    if (params.type === "img") {
        d.src = params.src;
    }
    if (params.appendChild) {
        d.appendChild(params.appendChild);
    }
    return d;
};

/*
  Handling events
  os.registerEvents(finderInput, {
      event: 'blur',
      callback: function () {
          closeFinder();
      }
  });
*/
os.registerEvents = function (obj, params) {
    try {
        if (typeof obj._eventListeners == 'undefined') {
            obj._eventListeners = [];
        }
        obj.addEventListener(params.event, params.callback);

        var eventListeners = obj._eventListeners;
        eventListeners.push(params);
        obj._eventListeners = eventListeners;
    } catch (ignore) {
        //  alert("os.js " + err);
    }
};

/*
  Removing Events
  os.unregisterEvents(finderInput);
*/
os.unregisterEvents = function (obj) {
    var i, e, len;
    if (typeof obj._eventListeners == 'undefined' || obj._eventListeners.length == 0) {
        return;
    }
    for (i = 0, len = obj._eventListeners.length; i < len; i += 1) {
        e = obj._eventListeners[i];
        obj.removeEventListener(e.event, e.callback);
    }
    obj._eventListeners = [];
};

//use clicks when on mobile or pc (mostly for testing)
os.handlerType = function () {
    var nav = navigator.userAgent.match(/iPhone|iPad|iPod/i);
    if (nav) {
        return 'touchstart';
    }
    return 'click';
};

os.detectDoubleTap = function () {
    if (!os.tapped) {
        os.tapped = setTimeout(function () {
            os.tapped = null;
            return false;
        }, 200);
    } else {
        clearTimeout(os.tapped); //stop single tap callback
        os.tapped = null;
        return true;
    }
};


os.showPopup = function (title, text) {
    if (showpopup) {
        var d = document;
        d.getElementById('notificationTitle').innerHTML = title;
        d.getElementById('notificationText').innerHTML = text;
        os.toggleClassList(d, 'notificationPopup', 'popupShow');

        setTimeout(function () {
            os.toggleClassList(d, 'notificationPopup', 'popupShow');
        }, popuptime);
    }
};

os.ipad = false;

os.resizeWidget = function () {
    document.getElementById('iWidget').style.height = screen.height + 'px';
    document.getElementById('iWidget').style.width = screen.width + 'px';
};

os.launchericon = function(url){
  document.getElementById('app1').src = url;
  localStorage.drawerimages = url;
  return "Icon Changed, use os.clearlaunchericon() to remove";
}
os.resetlaunchericon = function(){
  document.getElementById('app1').src = "src/images/launchpad.png";
  localStorage.removeItem('drawerimages');
  return "Removed launcher icon";
}
os.launchericonradius = function(radius){
  localStorage.launcherradius = radius;
  document.getElementById('app1').style.borderRadius = radius + "px";
  return "Launcher icon radius has been set to " + radius;
}


os.resetlaunchericonradius = function(){
  document.getElementById('app1').style.borderRadius = "0px";
  localStorage.removeItem('drawerimages');
  return "Launcher icon radius has been removed";
}

/*
  iWidgets don't rotate, to get a lanscape view you need to flip the height and width
  its on a class here, so just render a new style? Seems much less expensive.
  This is required to keep it somewhat "dynamic"

*/
os.setupLandscapeCss = function () {
    var css,
        width = screen.width,
        height = screen.height,
        position;
    if (screen.width === 320) { //iPhone 5
        position = "125px, 125px";
    } else if (screen.width >= 768) { //iPad Mini
        os.ipad = true;
        position = "128px, 128px";
    } else if (screen.width === 414) { //iPhone6S+
        position = "161px, 161px";
    } else {
        position = "146px, 146px"; //iPhone6
    }
    css = ".landscape{height: " + width + "px; width: " + height + "px;-webkit-transform: rotate(90deg) translate(" + position + ");background-position: 0px 0px;}";
    var style = document.createElement('style');
    style.type = 'text/css';
    style.appendChild(document.createTextNode(css));
    document.getElementsByTagName('head')[0].appendChild(style);
};

os.getFolders = function () { //os.message('sart');
    var dict = FPI.folderplist,
        iconList = dict.iconLists,
        folderObject = {},
        name,
        bundle;
    for (var i = 0; i < iconList.length; i++) {
        if (iconList[i].length > 0) {
            for (var v = 0; v < iconList[i].length; v++) {
                if (typeof iconList[i][v] === 'object') {
                    if (iconList[i][v].displayName != 'Newsstand') {
                        for (var e = 0; e < iconList[i][v].iconLists.length; e++) {
                            for (var f = 0; f < iconList[i][v].iconLists[e].length; f++) {
                                if (iconList[i][v].iconLists[e][f] != 'com.broganminer.anchor') {
                                    name = iconList[i][v].displayName;
                                    bundle = iconList[i][v].iconLists[e][f];
                                    if (folderObject[name]) {
                                        folderObject[name].push(bundle);
                                    } else {
                                        folderObject[name] = [];
                                        folderObject[name].push(bundle);
                                    }

                                }
                            }

                        }

                    }
                }
            }
        }
    }
    return folderObject;
};
os.checkApp = function (app) {
    /* fixes for icon bundles (to open the app) */
    if (app === 'com.agilebits.onepassword') {
        app = 'com.agilebits.onepassword-ios';
    }
    if (app === 'com.groupme.iphone') {
        app = 'com.groupme.iphone-app';
    }
    return app;
};
os.checkBundle = function (bundle) {
    /* Fixes for icon images */
    if (bundle === 'com.agilebits.onepassword') {
        bundle = 'com.agilebits.onepassword-ios';
    }
    if (bundle === 'com.groupme.iphone') {
        bundle = 'com.groupme.iphone-app';
    }
    if (bundle === 'com.cn') {
        bundle = 'com.cn-rulez.Blurify';
    }
    if (bundle === 'crash') {
        bundle = 'crash-reporter';
    }
    if (bundle === 'com.filippobiga.springtomize3') {
        bundle = 'com.filippobiga.springtomize3-app';
    }
    return bundle;
};
