/*jslint
  node: true,
  sloppy: true,
  browser: true,
  todo: true
*/

/*global
  os,
  IS2T,
  IS2S,
  alert,
  createMonth,
  notification,
  autohidedock,
  iconDrawer
*/



(function (window, doc) {
    function load_statusbar() {
        /*
          Provide easy access for terminal through
          statusbar.hidepercent(), statusbar.autocollapse(), etc..
        */
        var statusbar = {
                hide: localStorage.statusbarhide || false,
                dontcollapse: function () {
                    statusbar.hide = false;
                    doc.getElementById('statusbarExtras').style.opacity = 1;
                    localStorage.statusbarhide = false;
                    return true;
                },
                autocollapse: function () {
                    statusbar.hide = true;
                    doc.getElementById('statusbarExtras').style.opacity = 0;
                    localStorage.statusbarhide = true;
                    return true;
                },
                hidepercent: function () {
                    doc.getElementById('percent').style.display = 'none';
                    localStorage.hidepercent = true;
                    return true;
                },
                showpercent: function () {
                    doc.getElementById('percent').style.display = 'inline-block';
                    localStorage.removeItem('hidepercent');
                    return true;
                },
                bgcolor: function (color) {
                    doc.getElementById('statusbar').style.backgroundColor = color;
                    localStorage.bgcolor = color;
                    return true;
                },
                hidewifi: function () {
                    doc.getElementById('wifi').style.display = 'none';
                    localStorage.hidewifi = true;
                    return true;
                },
                showwifi: function () {
                    doc.getElementById('wifi').style.display = 'inline-block';
                    localStorage.removeItem('hidewifi');
                    return true;
                },
                hidebattery: function () {
                    doc.getElementById('batContainer').style.display = 'none';
                    localStorage.hidebattery = true;
                    return true;
                },
                showbattery: function () {
                    doc.getElementById('batContainer').style.display = 'inline-block';
                    localStorage.removeItem('hidebattery');
                    return true;
                },
                hidetime: function () {
                    doc.getElementById('clock').style.display = 'none';
                    localStorage.hidetime = true;
                    return true;
                },
                showtime: function () {
                    doc.getElementById('clock').style.display = 'inline-block';
                    localStorage.removeItem('hidetime');
                    return true;
                },
                methods: function () {
                    var res = [],
                        m;
                    for (m in statusbar) {
                        if (typeof statusbar[m] === "function") {
                            res.push(m + '<br>');
                        }
                    }
                    return res;
                }
            },
            extras = doc.getElementById('statusbarExtras'),
            timer = setTimeout(function () {
                if (statusbar.hide === true) {
                    extras.style.opacity = 0;
                }
                clearTimeout(timer);
            }, 10000),
            /*
              Each time a menu is tapped, reload it's data. This way you don't need it on a loop
            */
            loadMenuText = function (menu) {
                //load wifiMenu information
                if (menu === 'wifi') {
                    var name, upload, download, wifiTag, wifiButton;
                    // try {
                    //     if (IS2T('wifiEnabled')) {
                    //         name = IS2T('wifiName');
                    //         upload = IS2S('networkSpeedUpAutoConverted');
                    //         download = IS2S('networkSpeedDownAutoConverted');
                    //         wifiTag = 'Wifi: ';
                    //         wifiButton = 'Disable Wifi';
                    //     } else {
                    //         name = IS2T('phoneCarrier');
                    //         upload = "Quality: " + IS2T('phoneSignalRSSI');
                    //         download = IS2S('networkSpeedDownAutoConverted');
                    //         wifiTag = 'Service: ';
                    //         wifiButton = 'Enable Wifi';
                    //     }
                    //     doc.getElementById('wifiname').innerHTML = name;
                    //     doc.getElementById('upload').innerHTML = upload;
                    //     doc.getElementById('download').innerHTML = download;
                    //     doc.getElementById('wifiTag').innerHTML = wifiTag;
                    //     doc.getElementById('wifiButton').innerHTML = wifiButton;
                    // } catch (err) {
                    //     os.message('statusbar.js loadMeuText()', err);
                    // }
                }
                //load batteryMenu information
                // if (menu === 'battery') {
                //     try {
                //       FPI.system.battery
                //         doc.getElementById('batState').innerHTML = IS2S('batteryState') + ":";
                //         doc.getElementById('batPerc').innerHTML = IS2S('batteryPercent') + "%";
                //         doc.getElementById('ramu').innerHTML = IS2S('ramUsed') + "MB";
                //         doc.getElementById('ramf').innerHTML = IS2S('ramFree') + "MB";
                //         doc.getElementById('storageu').innerHTML = Math.round(IS2S('freeDiskSpaceInFormat:3')) + "GB";
                //         doc.getElementById('storagef').innerHTML = Math.round(IS2S('totalDiskSpaceInFormat:3')) + "GB";
                //     } catch (err) {
                //         os.message('statusbar.js menu === battery', err);
                //     }
                // }
            },
            /*
              Handle toggling of each menu (wifi, batterybar, clock), while detecting if statusbar should hide
            */
            openMenu = function (menu) {
                if (statusbar.hide === true) { // trigger hiding for the extra statusbar items
                    if (timer) {
                        clearTimeout(timer);
                    }
                    extras.style.opacity = 1;
                    timer = setTimeout(function () {
                        clearTimeout(timer);
                        extras.style.opacity = 0;
                    }, 5000);
                }
                os.toggleClassList(doc, menu + 'Menu', 'menuToggle'); //open menu
                os.closeAllMenusBesides(menu + 'Menu'); //close all menus besides this one
                loadMenuText(menu); //get new information
            },
            toggleExtras = function (title) {
                switch (title) {
                case 'wifi':
                    openMenu('wifi');
                    break;
                case 'batterybar':
                    openMenu('battery');
                    window.location = 'frontpage:updateMemory'; //update memory when batt memory is opened.
                    break;
                case 'clock':
                    if (doc.getElementById('calendarMenu').className === 'calendarMenu menuToggle') {
                        //createMonth(); //need to refresh calendar month
                        try {
                            calendar.createMonth();
                        } catch (err) {
                            //alert(err);
                        }
                    }
                    openMenu('calendar');
                    break;
                }
            };

        //add event to the extras section which holds wifi, batterybar
        os.registerEvents(extras, {
            event: os.handlerType(),
            callback: function (el) {
                toggleExtras(el.target.title);
            }
        });

        //add one more click handler for the clock for the calendar
        os.registerEvents(doc.getElementById('clock'), {
            event: os.handlerType(),
            callback: function (el) {
                toggleExtras('clock');
                el.preventDefault();
            }
        });
        //Trigger notification.js stuff
        os.registerEvents(doc.getElementById('notificationTrigger'), {
            event: os.handlerType(),
            callback: function () {
                if (document.getElementById('notificationMenu').className === "notificationMenu") {
                    notification.show();
                    doc.getElementById('dock').className = 'dockhide';
                    autohidedock = true;
                } else {
                    doc.getElementById('dock').className = 'dockshow';
                    autohidedock = false;
                    notification.hide();
                }
                os.toggleClassList(document, 'notificationMenu', 'notificationShow');
                os.closeAllMenusBesides('notificationMenu');
            }
        });

        os.registerEvents(doc.getElementById('wifiButton'), {
            event: os.handlerType(),
            callback: function () {
                var wifiButton = doc.getElementById('wifiButton');
                if (wifiButton.innerHTML === "Disable Wifi") {
                    disableWifi();
                    wifiButton.innerHTML = "Enable Wifi";
                } else if (wifiButton.innerHTML === "Enable Wifi") {
                    enableWifi();
                    wifiButton.innerHTML = "Disable Wifi";
                }
            }
        });

        if (localStorage.statusbarhide === true || localStorage.statusbarhide === "true") {
            statusbar.autocollapse();
        }
        return statusbar;
    }
    try {
        window.statusbar = load_statusbar();
    } catch (err) {
        os.message('statusbar.js load_statusbar()', err);
    }
}(window, document));
