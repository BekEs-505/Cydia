/*jslint
  node: true,
  sloppy: true,
  browser: true,
  todo: true
*/

/*global
  window,
  os,
  iconDrawer,
  appBundles,
  alert,
  macDock,
  IS2S,
  clock,
  IS2T,
  autohidedock,
  IS2M,
  twentyfour,
  widgetContainer
*/

//
//
//
//
// (function (doc) {


var doc = document;
var batteryPercent = doc.getElementById('batteryPercent'),
    batteryinsides = doc.getElementById('batteryinsides'),
    time = doc.getElementById('time'),
    wifi = doc.getElementById('wifi'),
    charging = doc.getElementById('batterycharging'),
    playDiv = doc.getElementById('play'),
    albumArtDiv = doc.getElementById('albumArt'),
    songDiv = doc.getElementById('song'),
    artistDiv = doc.getElementById('artist'),
    appDrawerDiv = doc.getElementById('appDrawerDiv'),
    dock = doc.getElementById('dock'),
    dwtime = doc.getElementById('dwtime'),
    dwday = doc.getElementById('dwday'),
    dwdate = doc.getElementById('dwdate'),
    songVar,
    artistVar,
    backVar,
    innerVar,
    savedImage,
    wifiState,
    wifiLocal,
    chargingBadge,
    dockState;
//
//     function handleMusic() {
//         if (IS2M('isPlaying')) {
//             songVar = IS2M('currentTrackTitle');
//             artistVar = IS2M('currentTrackArtist');
//             backVar = "url('" + IS2M('currentTrackArtworkBase64') + "')";
//             innerVar = 'X';
//             savedImage = true;
//
//         } else {
//             innerVar = 'x';
//             songVar = '';
//             artistVar = 'No music playing';
//             backVar = "url('src/images/music.jpg')";
//             savedImage = false;
//         }
//
//         if (playDiv.innerHTML !== innerVar) {
//             playDiv.innerHTML = innerVar;
//         }
//         if (albumArtDiv.style.backgroundImage.length !== backVar.length - 2 && savedImage === true) {
//             albumArtDiv.style.backgroundImage = backVar;
//         }
//         if (savedImage === false && albumArtDiv.style.backgroundImage.length !== 65) {
//             albumArtDiv.style.backgroundImage = backVar;
//         }
//         if (songDiv.innerHTML !== String(songVar)) {
//             songDiv.innerHTML = songVar;
//         }
//         if (artistDiv.innerHTML !== String(artistVar)) {
//             artistDiv.innerHTML = artistVar;
//         }
//     }
//
//
//     function shortLoop() {
//
//         macDock.setupDock();
//         batteryPercent.innerHTML = IS2S('batteryPercent') + "%";
//         batteryinsides.style.width = Math.round((IS2S('batteryPercent') / 100) * 18) + 'px';
//
//         if (IS2T('wifiEnabled')) {
//             wifiState = "url('src/images/wifi/wifi" + IS2T('wifiSignalBars') + ".png')";
//             wifiLocal = "url(file:///var/mobile/Library/iWidgets/Nyx/src/images/wifi/wifi" + IS2T('wifiSignalBars') + ".png)";
//         } else {
//             wifiState = "url('src/images/wifi/signal" + IS2T('phoneSignalBars') + ".png')";
//             wifiLocal = "url(file:///var/mobile/Library/iWidgets/Nyx/src/images/wifi/signal" + IS2T('phoneSignalBars') + ".png)";
//         }
//
//         if (wifi.style.backgroundImage !== wifiLocal) {
//             wifi.style.backgroundImage = wifiState;
//         }
//
//         if (autohidedock) {
//             dockState = 'dockhide';
//         } else {
//             dockState = 'dockshow';
//         }
//
//         if (dock.className !== dockState) {
//             if (appDrawerDiv.className === "appContainer drawerVisible") {
//                 if (dockState === 'dockhide') {
//                     dock.className = dockState;
//                 }
//             } else {
//                 dock.className = dockState;
//             }
//         }
//
//         if (IS2S('batteryStateAsInteger') === 2 || IS2S('batteryStateAsInteger') === 3) {
//             chargingBadge = 'block';
//         } else {
//             chargingBadge = 'none';
//         }
//
//         if (charging.style.display !== chargingBadge) {
//             charging.style.display = chargingBadge;
//         }
//
//         if (widgetContainer.isShowing) {
//             handleMusic();
//         }
//
//     }
//
//


//
//
// }(document));
