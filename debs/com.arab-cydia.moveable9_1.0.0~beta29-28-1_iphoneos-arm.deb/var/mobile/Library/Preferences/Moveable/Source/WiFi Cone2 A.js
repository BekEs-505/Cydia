(height, signalStrengthRaw, isTintBlack, extraOption, color)
{
	var lowerLimit = -96, upperLimit = -56;
	var range = Math.abs(lowerLimit - upperLimit)

	var percentage = 0;
	if (signalStrengthRaw <= lowerLimit) {
		percentage = 0;
	} else if (signalStrengthRaw >= upperLimit) {
		percentage = 1;
	} else {
		percentage = (signalStrengthRaw - lowerLimit) / range;
	}

	var
		canvas = document.createElement("canvas"),
		context = canvas.getContext("2d"),
		spacer = Math.round(height / 20.0),
		barHeight = height / 2.0,
		mainColor = "rgb(" + color.join() + ")",
		secondColor = "rgba(" + color.join() + ",0.3)",
		canvasHeight = height,
		canvasWidth = Math.round(1.6 * barHeight);

	canvas.width = canvasWidth;
	canvas.height = canvasHeight;

	cx = canvasWidth / 2.0;
	y1 = (canvasHeight - barHeight) / 2;
	y2 = barHeight + y1;
	
	radius = canvasHeight / 2.0;
	context.fillStyle = secondColor;
	context.save();
	context.beginPath();
	context.arc(cx, y2, radius, 0, 2 * Math.PI);
	context.clip();

	context.beginPath();
	context.moveTo(cx, y2);
	context.lineTo(0, y1);
	context.lineTo(0, 0);
	context.lineTo(canvasWidth, 0);
	context.lineTo(canvasWidth, y1);
	context.fill();
	context.restore();

	radius = Math.round(percentage * canvasHeight / 2.0);
	context.fillStyle = mainColor;
	context.beginPath();
	context.arc(cx, y2, radius, 0, 2 * Math.PI);
	context.clip();

	context.beginPath();
	context.moveTo(cx, y2);
	context.lineTo(0, y1);
	context.lineTo(0, 0);
	context.lineTo(canvasWidth, 0);
	context.lineTo(canvasWidth, y1);
	context.fill();

	return canvas.toDataURL("image/png");
}
