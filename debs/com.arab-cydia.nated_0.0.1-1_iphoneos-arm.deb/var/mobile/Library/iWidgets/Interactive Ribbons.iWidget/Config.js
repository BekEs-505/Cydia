/* 
Configurations
Credits: Original code by Dacal & Junesiphone & Matchstic. Modified by Evelyn & daddykool.
*/

var time = "24h";  // choose between "12h" or "24h"

var IconSet = "Klear";   // choose your weather icon pack here

var ChangeClick = true; // True ONLY if you have problem to show forecast when touch the screen


