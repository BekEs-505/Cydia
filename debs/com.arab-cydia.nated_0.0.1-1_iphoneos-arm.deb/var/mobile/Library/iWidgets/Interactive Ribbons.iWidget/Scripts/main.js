
var forecastdisplay = false;
var clockdisplay = false;
var datedisplay = false;
var weatherdisplay = false;


function touchEnd(event) {

if ( clockdisplay == false ) {
	document.getElementById('ClockWidget').style.webkitAnimationName = "ClockWidgetMoveUp";
	document.getElementById('ClockWidget').style.webkitAnimationDuration = "0.8s";
	clockdisplay = true;
	} else {
	document.getElementById('ClockWidget').style.webkitAnimationName = "ClockWidgetMoveDown";
	document.getElementById('ClockWidget').style.webkitAnimationDuration = "0.8s";
	clockdisplay = false;
	}
}


function touchEnd2(event) {

if ( datedisplay == false ) {
	document.getElementById('DateWidget').style.webkitAnimationName = "DateWidgetMoveUp";
	document.getElementById('DateWidget').style.webkitAnimationDuration = "0.8s";
	datedisplay = true;
	} else {
	document.getElementById('DateWidget').style.webkitAnimationName = "DateWidgetMoveDown";
	document.getElementById('DateWidget').style.webkitAnimationDuration = "0.8s";
	datedisplay = false;
    }
}

function touchEnd3(event) {

if ( weatherdisplay == false ) {
	document.getElementById('weatherIcon').style.webkitAnimationName = "weatherIconMoveUp";
	document.getElementById('weatherIcon').style.webkitAnimationDuration = "1.0s";
	document.getElementById('ribbon3').style.webkitAnimationName = "ribbon3MoveUp";
	document.getElementById('ribbon3').style.webkitAnimationDuration = "0.8s";
	document.getElementById('weatherContainer').style.webkitAnimationName = "weatherinfoMoveUp";
	document.getElementById('weatherContainer').style.webkitAnimationDuration = "0.8s";
	weatherdisplay = true;
	} else {
	document.getElementById('weatherIcon').style.webkitAnimationName = "weatherIconMoveDown";
	document.getElementById('weatherIcon').style.webkitAnimationDuration = "1.0s";
	document.getElementById('ribbon3').style.webkitAnimationName = "ribbon3MoveDown";
	document.getElementById('ribbon3').style.webkitAnimationDuration = "0.8s";
	document.getElementById('weatherContainer').style.webkitAnimationName = "weatherinfoMoveDown";
	document.getElementById('weatherContainer').style.webkitAnimationDuration = "0.8s";
	weatherdisplay = false;
	}
}


function touchEnd4(event) {

if ( forecastdisplay == false ) {
	document.getElementById('forecastContainer').style.webkitAnimationName = "forecastMoveUp";
	document.getElementById('forecastContainer').style.webkitAnimationDuration = "0.8s";
    document.getElementById('ribbon4').style.webkitAnimationName = "ribbon4MoveUp";
	document.getElementById('ribbon4').style.webkitAnimationDuration = "0.8s";

	forecastdisplay = true;
	} else {
	document.getElementById('forecastContainer').style.webkitAnimationName = "forecastMoveDown";
	document.getElementById('forecastContainer').style.webkitAnimationDuration = "0.8s";
    document.getElementById('ribbon4').style.webkitAnimationName = "ribbon4MoveDown";
	document.getElementById('ribbon4').style.webkitAnimationDuration = "0.8s";

	forecastdisplay = false;
	}
}



function init(){

var el = document.getElementById("TouchLayer1");
if ( ChangeClick == false ) {
	el.addEventListener("touchend", touchEnd, false);
	} else {
	el.addEventListener("click", touchEnd, false);
}

var el = document.getElementById("TouchLayer2");
if ( ChangeClick == false ) {
	el.addEventListener("touchend", touchEnd, false);
	} else {
	el.addEventListener("click", touchEnd2, false);

}

var el = document.getElementById("TouchLayer3");
if ( ChangeClick == false ) {
	el.addEventListener("touchend", touchEnd, false);
	} else {
	el.addEventListener("click", touchEnd3, false);
}

var el = document.getElementById("TouchLayer4");
if ( ChangeClick == false ) {
	el.addEventListener("touchend", touchEnd, false);
	} else {
	el.addEventListener("click", touchEnd4, false);
}
 }