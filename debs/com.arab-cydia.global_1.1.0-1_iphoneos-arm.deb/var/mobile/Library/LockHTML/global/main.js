var oDate;
var fDate;
var dayDate
var time1;
var time2;
var time3;
var time4;
var date1;
var date2;
var date3;
var date4;
var fHex;

function getTime(type, zone) {

if (type === "date") {
    oDate = new Date().toLocaleString('en-US', { timeZone: `${zone}` }).split(',');
    fDate = oDate[0];
    return fDate;
}

if (type === "time") {

    oDate = new Date().toLocaleString('en-US', { timeZone: `${zone}` }).split(',');
    fDate = oDate[1];
    return fDate;

}
}

function updateTime(zone1, zone2, zone3, zone4) {
// get times
time1 = getTime("time", zone1);
time2 = getTime("time", zone2);
time3 = getTime("time", zone3);
time4 = getTime("time", zone4);

// get dates
date1 = getTime("date", zone1);
date2 = getTime("date", zone2);
date3 = getTime("date", zone3);
date4 = getTime("date", zone4);

// get cities
city1 = zone1.split('/');
city2 = zone2.split('/');
city3 = zone3.split('/');
city4 = zone4.split('/');

document.getElementById("d1").innerHTML = date1;
document.getElementById("d2").innerHTML = date2;
document.getElementById("d3").innerHTML = date3;
document.getElementById("d4").innerHTML = date4;
document.getElementById("t1").innerHTML = time1;
document.getElementById("t2").innerHTML = time2;
document.getElementById("t3").innerHTML = time3;
document.getElementById("t4").innerHTML = time4;
document.getElementById("z1").innerHTML = city1[1];
document.getElementById("z2").innerHTML = city2[1];
document.getElementById("z3").innerHTML = city3[1];
document.getElementById("z4").innerHTML = city4[1];

fHex = hexToRgb(usrhex);

document.getElementById("u1").style.backgroundColor = `rgba(${fHex.r}, ${fHex.g}, ${fHex.b}, ${usrt})`;
document.getElementById("u2").style.backgroundColor = `rgba(${fHex.r}, ${fHex.g}, ${fHex.b}, ${usrt})`;
document.getElementById("u3").style.backgroundColor = `rgba(${fHex.r}, ${fHex.g}, ${fHex.b}, ${usrt})`;
document.getElementById("u4").style.backgroundColor = `rgba(${fHex.r}, ${fHex.g}, ${fHex.b}, ${usrt})`;


}

window.setInterval(function(){
    updateTime(usrz1, usrz2, usrz3, usrz4);
  }, 1000);

  function hexToRgb(hex) {
    // Expand shorthand form (e.g. "03F") to full form (e.g. "0033FF")
    var shorthandRegex = /^#?([a-f\d])([a-f\d])([a-f\d])$/i;
    hex = hex.replace(shorthandRegex, function(m, r, g, b) {
        return r + r + g + g + b + b;
    });

    var result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
        r: parseInt(result[1], 16),
        g: parseInt(result[2], 16),
        b: parseInt(result[3], 16)
    } : null;
}

